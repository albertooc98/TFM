from django.urls import path
from . import views

app_name = 'bdmed'
urlpatterns = [
    path('', views.IndexView, name='index'),
    path('detail/<int:id_detail>/', views.DetailView, name='detail'),
    path('upload_csv', views.UploadCsvView, name='upload_csv'),
    path('display_data/<str:order_variable>', views.DisplayDataView, name='display_data'),
    path('display_data', views.DisplayDataView, name='display_data'),
    path('reset_table', views.ResetTable, name='reset_table'),
    path('erase_table', views.EraseTable, name='erase_table'),
    path('eda_index', views.EDAIndexView, name='eda_index'),
    path('eda/<str:eda_variable>/<str:eda_variable2>', views.EDAView, name='eda'),
    path('select_variable', views.SelectVariableView, name='select_variable'),
    path('select_target', views.SelectTargetView, name='select_target'),
    path('problem_resolution', views.ProblemResolutionView, name='problem_resolution'),
    path('classification', views.ClassificationView, name='classification'),
    path('algorithm_selection/<str:problem_string>', views.AlgorithmSelectionView, name='algorithm_selection'),
    path('algorithm_set_up', views.AlgorithmSetUpView, name='algorithm_set_up'),
    path('result_analysis/<str:algorithm_string>/<int:id_instance>', views.ResultAnalysisView, name='result_analysis'),
    path('previous_results', views.PreviousResultsView, name='previous_results'),
    path('cluster_set_up', views.ClusterSetUpView, name='cluster_set_up'),
    path('test', views.TestView, name='test'),
    
]