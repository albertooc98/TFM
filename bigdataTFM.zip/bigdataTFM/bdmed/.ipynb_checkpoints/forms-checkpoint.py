from django import forms

CMBD_CHOICES = (
    ('TIPALTTarget', 'TIPALTTarget'),
    ('TIPINGTarget', 'TIPINGTarget'),
    ('TIEMPOINGTarget', 'TIEMPOINGTarget'),
)

class CMBDSelectionForm(forms.Form):
    TXTFECNAC = forms.BooleanField(required = False)
    SEXO = forms.BooleanField(required = False, initial = True)
    PROCEDE = forms.BooleanField(required = False, initial = True)
    TXTFECCONT = forms.BooleanField(required = False)
    TXTFECING = forms.BooleanField(required = False)
    TIPING = forms.BooleanField(required = False)
    TXTFECALT = forms.BooleanField(required = False)
    TIPALT = forms.BooleanField(required = False)
    CONTINUIDA = forms.BooleanField(required = False, initial = True)
    TRASH = forms.BooleanField(required = False)
    MUNIRESI = forms.BooleanField(required = False)
    PAISNAC = forms.BooleanField(required = False, initial = True)
    REGFIN = forms.BooleanField(required = False, initial = True)
    UCI = forms.BooleanField(required = False, initial = True)
    DIASUCI = forms.BooleanField(required = False, initial = True)
    EDAD = forms.BooleanField(required = False, initial = True)
    TIEMPOING = forms.BooleanField(required = False)
    MES = forms.BooleanField(required = False)
    MESNUM = forms.BooleanField(required = False)
    ESTACION = forms.BooleanField(required = False, initial = True)
    C1 = forms.BooleanField(required = False, initial = True)
    ANO = forms.BooleanField(required = False)

Bank_CHOICES = (
    ('depositTarget', 'depositTarget'),
)    
    
class BankSelectionForm(forms.Form):
    age = forms.BooleanField(required = False, initial = True) 
    job = forms.BooleanField(required = False, initial = True) 
    marital = forms.BooleanField(required = False, initial = True) 
    education = forms.BooleanField(required = False, initial = True) 
    default = forms.BooleanField(required = False) 
    balance = forms.BooleanField(required = False) 
    housing = forms.BooleanField(required = False) 
    loan = forms.BooleanField(required = False) 
    contact = forms.BooleanField(required = False) 
    day = forms.BooleanField(required = False) 
    month = forms.BooleanField(required = False) 
    duration = forms.BooleanField(required = False) 
    campaign = forms.BooleanField(required = False) 
    pdays = forms.BooleanField(required = False) 
    previous = forms.BooleanField(required = False) 
    poutcome = forms.BooleanField(required = False) 
    deposit = forms.BooleanField(required = False)
    
Iris_CHOICES = (
    ('varietyTarget', 'varietyTarget'),
)      
    
class IrisSelectionForm(forms.Form):
    sepalLength = forms.BooleanField(required = False, initial = True) 
    sepalWidth = forms.BooleanField(required = False, initial = True) 
    petalLength = forms.BooleanField(required = False, initial = True)
    petalWidth = forms.BooleanField(required = False, initial = True)
    variety = forms.BooleanField(required = False)

AcuteInflammations_CHOICES = (
    ('InflammationOfUrinaryBladderTarget', 'InflammationOfUrinaryBladderTarget'),
    ('NephritisOfRenalPelvisOriginTarget','NephritisOfRenalPelvisOriginTarget'),
)     
    
class AcuteInflammationsSelectionForm(forms.Form):
    TemperatureOfPatient = forms.BooleanField(required = False, initial = True) 
    OccurrenceOfNausea = forms.BooleanField(required = False, initial = True) 
    LumbarPain = forms.BooleanField(required = False, initial = True)
    UrinePushing = forms.BooleanField(required = False, initial = True) 
    MicturitionPains = forms.BooleanField(required = False, initial = True) 
    BurningOfUrethra = forms.BooleanField(required = False, initial = True) 
    InflammationOfUrinaryBladder = forms.BooleanField(required = False, initial = True) 
    NephritisOfRenalPelvisOrigin = forms.BooleanField(required = False)

MedicalCost_CHOICES = (
    ('ChargesTarget', 'ChargesTarget'),
)     
    
class MedicalCostSelectionForm(forms.Form):
    Age = forms.BooleanField(required = False, initial = True) 
    Sex = forms.BooleanField(required = False, initial = True) 
    Bmi = forms.BooleanField(required = False, initial = True) 
    Children = forms.BooleanField(required = False, initial = True) 
    Smoker = forms.BooleanField(required = False, initial = True) 
    Region = forms.BooleanField(required = False, initial = True) 
    Charges = forms.BooleanField(required = False)

ContraceptiveMethod_CHOICES = (
    ('ContraceptiveMethodTarget', 'ContraceptiveMethodTarget'),
)  
    
class ContraceptiveMethodSelectionForm(forms.Form):
    WifeAge = forms.BooleanField(required = False, initial = True) 
    WifeEducation = forms.BooleanField(required = False, initial = True) 
    HusbandEducation = forms.BooleanField(required = False, initial = True) 
    NumberBorn = forms.BooleanField(required = False, initial = True) 
    WifeReligion = forms.BooleanField(required = False, initial = True) 
    WifeWorking = forms.BooleanField(required = False, initial = True) 
    HusbandOccupation = forms.BooleanField(required = False, initial = True) 
    StandardOfLivingIndex = forms.BooleanField(required = False, initial = True) 
    MediaExposure = forms.BooleanField(required = False, initial = True) 
    ContraceptiveMethod = forms.BooleanField(required = False) 
    
    def __str__(self):
        return str(self.Id)

class EdaUnivariableForm(forms.Form):
    Variable = forms.MultipleChoiceField(widget=forms.CheckboxSelectMultiple, required = True)
    
    def select_eda_variable(self, variable_choices, *args, **kwargs):
        super(EdaUnivariableForm, self).__init__(*args, **kwargs)
        self.fields['Variable'].choices = variable_choices
        
class EdaBivariableForm(forms.Form):
    Variable = forms.MultipleChoiceField(widget=forms.RadioSelect, required = True)
    
    def select_eda_variable(self, variable_choices, *args, **kwargs):
        super(EdaBivariableForm, self).__init__(*args, **kwargs)
        self.fields['Variable'].choices = variable_choices
    
class TargetForm(forms.Form):
    Target = forms.MultipleChoiceField(widget=forms.RadioSelect, required = True)
    
    def create_target(self, variable_choices, *args, **kwargs):
        super(TargetForm, self).__init__(*args, **kwargs)
        self.fields['Target'].choices = variable_choices
        
class TargetFormChar(forms.Form):
    Target = forms.CharField(required = True)
        
class VariableFilterForm(forms.Form):
    variable = forms.ChoiceField(required=False)
    operator = forms.ChoiceField(required=False,  choices = (
        ("exact", "exact"),
        ("iexact", "iexact"),
        ("contains", "contains"),
        ("icontains", "icontains"),
        ("gt", "gt"),
        ("gte", "gte"),
        ("lt", "lt"),
        ("lte", "lte"),
        ("startswith", "startswith"),
        ("istartswith", "istartswith"),
        ("endswith", "endswith"),
        ("iendswith", "iendswith"),
        ("regex", "regex"),
        ("iregex", "iregex"),
        )
    )
    value = forms.CharField(required=False)
    
    def create_variables(self, variable_choices, *args, **kwargs):
        super(VariableFilterForm, self).__init__(*args, **kwargs)
        self.fields['variable'].choices = variable_choices
        
class VariableFilterFormChar(forms.Form):
    variable = forms.CharField(required=False)
    operator = forms.CharField(required=False)
    value = forms.CharField(required=False)

MODEL_CHOICES = (
    ('CMBD', 'CMBD'),
    ('Bank', 'Bank'),
    ('Iris', 'Iris'),
    ('AcuteInflammations', 'AcuteInflammations'),
    ('MedicalCost', 'MedicalCost'),
    ('ContraceptiveMethod', 'ContraceptiveMethod'),
)    
    
class ModelSelectionForm(forms.Form):
    Model = forms.ChoiceField(required=False,  choices = MODEL_CHOICES)
    
class ModelSelectionFormChar(forms.Form):
    Model = forms.CharField(required = True)

BINARY_ALGORITHM_CHOICES = (
    ('BinaryLogisticRegression', 'BinaryLogisticRegression'),
    ('BinaryDecisionTree', 'BinaryDecisionTree'),
    ('BinaryRandomForest', 'BinaryRandomForest'),
    ('BinaryGBT', 'BinaryGBT'),
    ('BinaryNaiveBayes', 'BinaryNaiveBayes'),
    ('BinaryLinearSVC', 'BinaryLinearSVC'),
)    
    
class BinaryClassificationAlgorithmSelectionForm(forms.Form):
    Algorithm = forms.MultipleChoiceField(widget=forms.RadioSelect, choices=BINARY_ALGORITHM_CHOICES, required = True)
    
class BinaryClassificationAlgorithmSelectionFormChar(forms.Form):
    Algorithm = forms.CharField(required = True)

MULTICLASS_ALGORITHM_CHOICES = (
    ('MulticlassLogisticRegression', 'MulticlassLogisticRegression'),
    ('MulticlassDecisionTree', 'MulticlassDecisionTree'),
    ('MulticlassRandomForest', 'MulticlassRandomForest'),
    ('MulticlassNaiveBayes', 'MulticlassNaiveBayes'),
)       
    
class MulticlassClassificationAlgorithmSelectionForm(forms.Form):
    Algorithm = forms.MultipleChoiceField(widget=forms.RadioSelect, choices=MULTICLASS_ALGORITHM_CHOICES, required = True)

class MulticlassClassificationAlgorithmSelectionFormChar(forms.Form):
    Algorithm = forms.CharField(required = True)

REGRESSION_ALGORITHM_CHOICES = (
    ('DecisionTreeRegression', 'DecisionTreeRegression'),
    ('RandomForestRegression', 'RandomForestRegression'),
    ('GBTRegression', 'GBTRegression'),
)       
    
class RegressionAlgorithmSelectionForm(forms.Form):
    Algorithm = forms.MultipleChoiceField(widget=forms.RadioSelect, choices=REGRESSION_ALGORITHM_CHOICES, required = True)

class RegressionAlgorithmSelectionFormChar(forms.Form):
    Algorithm = forms.CharField(required = True)
    
# Choices for the algorithm variables

IMPURITY_DT_RF_CHOICES = [
    ('gini', 'gini'),
    ('entropy', 'entropy')
]

IMPURITY_GBT_CHOICES = [
    ('variance', 'variance')
]

LOSSTYPES_GBT_CHOICES = [
    ('logistic', 'logistic')
]

FSS_CHOICES = [
    ('auto', 'auto'),
    ('all', 'all'),
    ('onethird', 'onethird'),
    ('sqrt', 'sqrt'),
    ('log2', 'log2')
]

MODELTYPE_NAIVEBAYES_CHOICES = [
    ('multinomial ', 'multinomial '),
    ('bernoulli', 'bernoulli'),
    ('gaussian', 'gaussian')
]

IMPURITY_REGRESSION_CHOICES = [
    ('variance', 'variance')
]

LOSSTYPE_REGRESSION_CHOICES = [
    ('squared', 'squared'),
    ('absolute', 'absolute')
]

# Forms of classification algorithms, same for binary and multiclass classification

class LogisticRegressionForm(forms.Form):
    maxIter = forms.IntegerField(required=True, min_value = 0)
    parallelism = forms.IntegerField(required=True, initial = 8, min_value = 1)
    nfolds = forms.IntegerField(required=True, min_value = 1)
    
class DecisionTreeForm(forms.Form):
    parallelism = forms.IntegerField(required=True, initial = 8, min_value = 1)
    nfolds = forms.IntegerField(required=True, initial = 10, min_value = 1)
    maxDepth = forms.IntegerField(required=True, initial = 5, min_value = 0)
    maxBins = forms.IntegerField(required=True, initial = 32, min_value = 2)
    minInstancesPerNode = forms.IntegerField(required=True, initial = 1, min_value = 1)
    minInfoGain = forms.FloatField(required=True, initial = 0.0)
    maxMemoryInMB = forms.IntegerField(required=True, initial = 256)
    impurity = forms.ChoiceField(required=True,  choices = IMPURITY_DT_RF_CHOICES)
    
class DecisionTreeFormChar(forms.Form):
    parallelism = forms.IntegerField(required=True)
    nfolds = forms.IntegerField(required=True)
    maxDepth = forms.IntegerField(required=True)
    maxBins = forms.IntegerField(required=True)
    minInstancesPerNode = forms.IntegerField(required=True)
    minInfoGain = forms.FloatField(required=True)
    maxMemoryInMB = forms.IntegerField(required=True)
    impurity = forms.CharField(required=True)
    
class RandomForestForm(forms.Form):
    parallelism = forms.IntegerField(required=True, initial = 8, min_value = 1)
    nfolds = forms.IntegerField(required=True, initial = 10, min_value = 1)
    maxDepth = forms.IntegerField(required=True, initial = 5, min_value = 0)
    maxBins = forms.IntegerField(required=True, initial = 32, min_value = 2)
    minInstancesPerNode = forms.IntegerField(required=True, initial = 1, min_value = 1)
    minInfoGain = forms.FloatField(required=True, initial = 0.0)
    maxMemoryInMB = forms.IntegerField(required=True, initial = 256)
    impurity = forms.ChoiceField(required=True,  choices = IMPURITY_DT_RF_CHOICES)
    subsamplingRate = forms.FloatField(required=True, initial = 1.0, min_value = 0.00000001, max_value = 1)
    featureSubsetStrategy = forms.ChoiceField(required=True,  choices = FSS_CHOICES)
    numTrees = forms.IntegerField(required=True, initial = 10, min_value = 1)
    bootstrap = forms.BooleanField(required = False, initial = True)
    
class RandomForestFormChar(forms.Form):
    parallelism = forms.IntegerField(required=True)
    nfolds = forms.IntegerField(required=True)
    maxDepth = forms.IntegerField(required=True)
    maxBins = forms.IntegerField(required=True)
    minInstancesPerNode = forms.IntegerField(required=True)
    minInfoGain = forms.FloatField(required=True)
    maxMemoryInMB = forms.IntegerField(required=True)
    impurity = forms.CharField(required=True)
    subsamplingRate = forms.FloatField(required=True)
    featureSubsetStrategy = forms.CharField(required=True)
    numTrees = forms.IntegerField(required=True)
    bootstrap = forms.BooleanField(required = True)
    
class GBTForm(forms.Form):
    parallelism = forms.IntegerField(required=True, initial = 8, min_value = 1)
    nfolds = forms.IntegerField(required=True, initial = 10, min_value = 1)
    maxDepth = forms.IntegerField(required=True, initial = 5, min_value = 0)
    maxBins = forms.IntegerField(required=True, initial = 32, min_value = 2)
    minInstancesPerNode = forms.IntegerField(required=True, initial = 1, min_value = 1)
    minInfoGain = forms.FloatField(required=True, initial = 0.0)
    maxMemoryInMB = forms.IntegerField(required=True, initial = 256)
    impurity = forms.ChoiceField(required=True,  choices = IMPURITY_GBT_CHOICES)
    subsamplingRate = forms.FloatField(required=True, initial = 1.0, min_value = 0.00000001, max_value = 1) 
    featureSubsetStrategy = forms.ChoiceField(required=True,  choices = FSS_CHOICES)
    maxIter = forms.IntegerField(required=True, initial = 20, min_value = 0)
    lossType = forms.ChoiceField(required=True,  choices = LOSSTYPES_GBT_CHOICES)
    validationTol = forms.FloatField(required=True, initial = 0.01)
    stepSize = forms.FloatField(required=True, initial = 0.1, min_value = 0.00000001, max_value = 1)
    minWeightFractionPerNode = forms.FloatField(required=True, initial = 0.0, min_value = 0, max_value = 0.499999999)
    
class GBTFormChar(forms.Form):
    parallelism = forms.IntegerField(required=True)
    nfolds = forms.IntegerField(required=True)
    maxDepth = forms.IntegerField(required=True) 
    maxBins = forms.IntegerField(required=True) 
    minInstancesPerNode = forms.IntegerField(required=True) 
    minInfoGain = forms.FloatField(required=True) 
    maxMemoryInMB = forms.IntegerField(required=True) 
    impurity = forms.CharField(required=True) 
    subsamplingRate = forms.FloatField(required=True) 
    featureSubsetStrategy = forms.CharField(required=True) 
    maxIter = forms.IntegerField(required=True)
    lossType = forms.CharField(required=True)
    validationTol = forms.FloatField(required=True)
    stepSize = forms.FloatField(required=True)
    minWeightFractionPerNode = forms.FloatField(required=True)
    
class NaiveBayesForm(forms.Form):
    parallelism = forms.IntegerField(required=True, initial = 8, min_value = 1)
    nfolds = forms.IntegerField(required=True, initial = 10, min_value = 1)
    smoothing = forms.FloatField(required=True, initial = 1.0, min_value = 0)
    modelType = forms.ChoiceField(required=True,  choices = MODELTYPE_NAIVEBAYES_CHOICES)
    
class NaiveBayesFormChar(forms.Form):
    parallelism = forms.IntegerField(required=True)
    nfolds = forms.IntegerField(required=True)
    smoothing = forms.FloatField(required=True)
    modelType = forms.CharField(required=True)   

class LinearSVCForm(forms.Form):
    parallelism = forms.IntegerField(required=True, initial = 8, min_value = 1)
    nfolds = forms.IntegerField(required=True, initial = 10, min_value = 1)
    aggregationDepth = forms.IntegerField(required=True, initial = 2, min_value = 2)
    maxIter = forms.IntegerField(required=True, initial = 100, min_value = 0)
    regParam = forms.FloatField(required=True, initial = 0.0, min_value = 0.0)
    standardization = forms.BooleanField(required = False, initial = True)
    tol = forms.FloatField(required=True, initial = 0.000001, min_value = 0)
    
class DecisionTreeRegressionForm(forms.Form):
    parallelism = forms.IntegerField(required=True, initial = 8, min_value = 1)
    nfolds = forms.IntegerField(required=True, initial = 10, min_value = 1)
    maxDepth = forms.IntegerField(required=True, initial = 5, min_value = 0)
    maxBins = forms.IntegerField(required=True, initial = 32, min_value = 2)
    minInstancesPerNode = forms.IntegerField(required=True, initial = 1, min_value = 1)
    minInfoGain = forms.FloatField(required=True, initial = 0.0)
    maxMemoryInMB = forms.IntegerField(required=True, initial = 256)
    impurity = forms.ChoiceField(required=True,  choices = IMPURITY_REGRESSION_CHOICES)
    
class RandomForestRegressionForm(forms.Form):
    parallelism = forms.IntegerField(required=True, initial = 8, min_value = 1)
    nfolds = forms.IntegerField(required=True, initial = 10, min_value = 1)
    maxDepth = forms.IntegerField(required=True, initial = 5, min_value = 0)
    maxBins = forms.IntegerField(required=True, initial = 32, min_value = 2)
    minInstancesPerNode = forms.IntegerField(required=True, initial = 1, min_value = 1)
    minInfoGain = forms.FloatField(required=True, initial = 0.0)
    maxMemoryInMB = forms.IntegerField(required=True, initial = 256)
    impurity = forms.ChoiceField(required=True,  choices = IMPURITY_REGRESSION_CHOICES)
    subsamplingRate = forms.FloatField(required=True, initial = 1.0, min_value = 0.00000001, max_value = 1)
    featureSubsetStrategy = forms.ChoiceField(required=True,  choices = FSS_CHOICES)
    numTrees = forms.IntegerField(required=True, initial = 10, min_value = 1)
    bootstrap = forms.BooleanField(required = False, initial = True)
    
class GBTRegressionForm(forms.Form):
    parallelism = forms.IntegerField(required=True, initial = 8, min_value = 1)
    nfolds = forms.IntegerField(required=True, initial = 10, min_value = 1)
    maxDepth = forms.IntegerField(required=True, initial = 5, min_value = 0)
    maxBins = forms.IntegerField(required=True, initial = 32, min_value = 2) 
    minInstancesPerNode = forms.IntegerField(required=True, initial = 1, min_value = 1) 
    minInfoGain = forms.FloatField(required=True, initial = 0.0) 
    maxMemoryInMB = forms.IntegerField(required=True, initial = 256) 
    impurity = forms.ChoiceField(required=True,  choices = IMPURITY_REGRESSION_CHOICES)
    subsamplingRate = forms.FloatField(required=True, initial = 1.0, min_value = 0.00000001, max_value = 1) 
    featureSubsetStrategy = forms.ChoiceField(required=True,  choices = FSS_CHOICES)
    maxIter = forms.IntegerField(required=True, initial = 20, min_value = 0)
    lossType = forms.ChoiceField(required=True,  choices = LOSSTYPE_REGRESSION_CHOICES)
    validationTol = forms.FloatField(required=True, initial = 0.01)
    stepSize = forms.FloatField(required=True, initial = 0.1, min_value = 0.00000001, max_value = 1)
    minWeightFractionPerNode = forms.FloatField(required=True, initial = 0.0, min_value = 0, max_value = 0.499999999)
    
# form for the cluster execution
class ClusterSetUpForm(forms.Form):
    Distributed = forms.BooleanField(required = False, initial = False)
    ConexionToSparkMaster = forms.CharField(required=True, initial = 'spark://172.21.96.1:7077')  
    NumberOfCores = forms.IntegerField(required=True, initial = 8, min_value = 1)
    NumberOfCoresPerExecutor = forms.IntegerField(required=True, initial = 1, min_value = 1)
    ExecutorMemory = forms.IntegerField(required=True, initial = 1, min_value = 1)
