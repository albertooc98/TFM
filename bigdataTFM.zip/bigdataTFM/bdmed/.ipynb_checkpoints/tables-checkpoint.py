import django_tables2 as tables
from .models import HospitalMarbella
from .models import Bank

class HospitalMarbellaTable(tables.Table):
    class Meta:
        model = HospitalMarbella
        template_name = "django_tables2/bootstrap.html"
        
class BankTable(tables.Table):
    class Meta:
        model = Bank
        template_name = "django_tables2/bootstrap.html"