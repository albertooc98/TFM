# Django imports - generics
from django.shortcuts import get_object_or_404, render
from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader
from django.http import Http404
from django.urls import reverse
from django.views import generic
from django.conf import settings
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

# Django models imports
from .models import *

# For debugging
import logging

# Import of own functions
from .functions import preprocessing # for CMDB data preprocessing
from .functions import stringfunctions # for getting images and string manipulation
from .functions import eda # for getting images and string manipulation
from .functions import sparkpreprocessing # for spark algorithm's required preprocessing
from .functions import sparkclassificationalgorithms # for running classification algorithms
from .functions import sparkregressionalgorithms # for running regression algorithms

# Python standard useful libraries
import pandas as pd
from io import StringIO
import numpy as np
import sys
from contextlib import redirect_stdout
import os
import time
import itertools

# Eda and Statistics
import seaborn as sns
import missingno as msno
import statistics
import statsmodels.api as sm
from scipy import stats

# Plot
import matplotlib.pyplot as plt

# Pyspark
from pyspark import SparkContext, SparkConf
from pyspark.sql import SparkSession

# SQLAlchemy, for pandas to insert data in local SQL Database
from sqlalchemy import create_engine

# Forms
from .forms import *

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# Index View of the app - shows links to app's main options and allows to do custom querys (this will be done using django tables)
def IndexView(request):
    
    # Logger set up
    logger = logging.getLogger('app_api')
    
    # Set up default model
    if (not (request.session.get('model', None))):
        request.session['model'] = "CMBD"
        chosen_model = "CMBD"
        model_string = "El modelo activo es (por defecto): "
    else:
        chosen_model = request.session['model']
        model_string = "El modelo activo es: "

    if ("GET" == request.method):
        
        form = ModelSelectionForm()
        
        return render(request, "bdmed/index.html", {'form': form, 'chosen_model':chosen_model, 'model_string':model_string})
    
    # if not get, then POST 
    else:
       
        # create a form instance and populate it with data from the request:
        form = ModelSelectionFormChar(request.POST)
        
        # check whether it's valid:
        if form.is_valid():
            
            request.session['model'] = form.cleaned_data['Model']
                    
        return HttpResponseRedirect(reverse("bdmed:index"))


# Detailed view of the fields of each patient
def DetailView(request, id_detail):
    template_name = 'bdmed/detail.html'
    
    model = globals()[request.session['model']]
    
    data = model.objects.filter(Id=int(id_detail)).values()
    
    # Get column names
    fields_ini = model._meta.fields
    variable_names = []
        
    for variable in fields_ini:
        position = stringfunctions.find_nth(str(variable), '.', 2)
        var_name = str(variable)[position+1:]
        variable_names.append(var_name)

    return render(request, "bdmed/detail.html", {'data':data, 'model':request.session['model'], 'variable_names':variable_names, 'Id': id_detail})

# Details of the patients in the database using django tables 2 
def DisplayDataView(request, order_variable = ''):
    
    model = globals()[request.session['model']]
    template_name = 'bdmed/display_data.html'
    
    logger = logging.getLogger('app_api')
        
    if ("GET" == request.method):

        # get filter variable, operator and value for getting the filtered data and then get the filtered data from the session variables filled in POST Section
        if ( (not (request.session.get('variable_filter', None))) and (not (request.session.get('operator_filter', None))) and (not (request.session.get('value_filter', None))) ):
            data_filtered = model.objects.all().values() # Data as dictionary

        else:
            
            # build the filter
            filter_keyword = request.session['variable_filter'] + '__' + request.session['operator_filter']
            
            # check if the expected value is a 
            filter_value = request.session['value_filter']

            DD_filter = {}
            DD_filter[filter_keyword] = filter_value

            data_filtered = model.objects.filter(**DD_filter).values()
        
        # set up paginator
        page = request.GET.get('page', 1)
        paginator = Paginator(data_filtered, 20)
        try:
            data = paginator.page(page)
        except PageNotAnInteger:
            data = paginator.page(1)
        except EmptyPage:
            data = paginator.page(paginator.num_pages)
            
        # sort values by variable if needed and keep the current order
        dictionary_list = [] 
        if (order_variable != ''):
            
            # create a dataframe and sort it
            
            # build the df with the columns
            list_aux = pd.DataFrame(data[0].items()).transpose().values.tolist()
            cols = list_aux[0]
            df = pd.DataFrame(columns=cols)
            
            # insert all the rows (20 from pagination)
            for elem in data:
                list_aux = pd.DataFrame(elem.items()).transpose().values.tolist()
                df.loc[len(df)] = list_aux[1]
            
            # order the df descending/ascending
            if (order_variable[0] == "-"):
                current_order = "-"
                df.sort_values(by=order_variable[1:], inplace=True, ascending=False, ignore_index = True)
            else:
                current_order = "+"
                df.sort_values(by=order_variable, inplace=True, ignore_index = True)
            
            # Build the dictionary list
            for i in range(len(df)):
                df_aux = pd.DataFrame(columns=cols)
                df_aux.loc[0] = df.loc[i]
                dictionary_list.append(df_aux.to_dict('records'))
                
        else:
            current_order = 'none'

        # Get column names and build the form
        fields_ini = model._meta.fields
        variable_names = []
        variable_pairs_form = []
    
        for variable in fields_ini:
            position = stringfunctions.find_nth(str(variable), '.', 2)
            var_name = str(variable)[position+1:]
            variable_names.append(var_name)
            variable_pairs_form.append((var_name, var_name))
            
        # get the empty filter form
        form = VariableFilterForm()
        
        # create dynamic choices in the form
        form.create_variables(variable_pairs_form)
        
        return render(request, "bdmed/display_data.html", {'form':form, 'data':data, 'variable_names':variable_names, 'page':page, 'current_order':current_order, 'dictionary_list':dictionary_list, 'model':request.session['model']})
    
    else:
                
        # create a form instance and populate it with data from the request:
        form = VariableFilterFormChar(request.POST)
        
        # check whether it's valid:
        if form.is_valid():
            
            # For the classification algorithms view
            request.session['variable_filter'] = form.cleaned_data['variable']
            request.session['operator_filter'] = form.cleaned_data['operator']
            request.session['value_filter'] = form.cleaned_data['value']

            return HttpResponseRedirect(reverse("bdmed:display_data"))

def ResetTable(request):
    
    # clean session variables
    if ((request.session.get('variable_filter', None))):
        del request.session['variable_filter']
        
    if ((request.session.get('operator_filter', None))):
        del request.session['operator_filter']
        
    if ((request.session.get('value_filter', None))):
        del request.session['value_filter']
        
    request.session.modified = True
    
    return HttpResponseRedirect(reverse("bdmed:display_data"))

def EraseTable(request):
    
    model = globals()[request.session['model']]
    model.objects.all().delete()
    
    return HttpResponseRedirect(reverse("bdmed:display_data"))
    

# View to add patients to user's local SQL database
def UploadCsvView(request):
    template = loader.get_template('bdmed/upload_csv.html')
    data = request.session['model']

    if ("GET" == request.method):
        return render(request, "bdmed/upload_csv.html",  {'data': data})
    
    # if not get, then POST 
    else:
        
        # get the file from the request
        csv_file = request.FILES["csv_file"]
        
        # check if .csv extension is correct
        if not csv_file.name.endswith('.csv'):
            return render(request, "bdmed/upload_csv.html", {'data': data , 'error_extension': True})
        
        # set MAX SIZE
        MAX_SIZE = 104857600
        
        # check file length
        if (csv_file.size > MAX_SIZE) :
            return render(request, "bdmed/upload_csv.html", {'data': data , 'error_size': True})

        # decode the file and build a dataframe from it
        file_data = csv_file.read().decode("utf-8")
        file_data_string = StringIO(file_data)
        df = pd.read_csv(file_data_string, sep=';')
                
        if (request.session['model'] == "CMBD"):
            # Aquí se adjuntarán parámetros desde el form, como el nivel de mapeo
            
            # Se aplica el preprocesado de los datos (nivel de mapeo 1, por defecto)
            df_final = preprocessing.preprocessCMBD(df)
            
        else:
            df_final = df

        database_name = str(settings.DATABASES['default']['NAME'])
        database_url = 'sqlite:///' + database_name
        
        engine = create_engine(database_url, echo=False)
        
        table_name = 'bdmed_' + request.session['model'].lower()
        
        df_final.to_sql(table_name, con=engine, if_exists='append', index=False)
        
        return HttpResponseRedirect(reverse("bdmed:index"))

# Index of the EDA - shows all the available variables. Link to univariable analysis
def EDAIndexView(request):
    
    model = globals()[request.session['model']]
    
    if ("GET" == request.method):
    
        # Get all the fields of variable of the patient's model
        data_ini = model._meta.fields
        variable_pair_list = []
        for variable in data_ini:
            position = stringfunctions.find_nth(str(variable), '.', 2)
            var_string = str(variable)[position+1:]
            variable_pair_list.append((var_string, var_string))

        form = EdaUnivariableForm()
        form.select_eda_variable(variable_pair_list)

        data = variable_pair_list
                
        # if there is not an error message to display
        if (not (request.session.get('error', None))):
            return render(request, "bdmed/eda_index.html", {'data': data, 'form':form, 'model':request.session['model'] })
        
        else:
            return render(request, "bdmed/eda_index.html", {'data': data, 'form':form, 'error_message': request.session['error'], 'error': True, 'model':request.session['model']})
        
    
    else:
        
        # get list with the selected variables of the form
        eda_variables = request.POST.getlist('Variable')
        
        # univariate analysis
        if (len(eda_variables) == 1):
            
            # remove the error message if there is one
            if (request.session.get('error', None)):
                del request.session['error']
                
            return HttpResponseRedirect(reverse('bdmed:eda', args=[eda_variables[0], '0']))
        
        elif (len(eda_variables) == 2):
            
            # remove the error message if there is one
            if (request.session.get('error', None)):
                del request.session['error']
                
            return HttpResponseRedirect(reverse('bdmed:eda', args=[eda_variables[0], eda_variables[1]]))
        
        else:
        
            request.session['error'] = 'Han de seleccionarse 1 o 2 variables para el EDA'
            
            return HttpResponseRedirect(reverse("bdmed:eda_index"))
        
        

# View of the EDA, param are the name of two of the model's fields. If second variable is '0' -> univariate analysis
def EDAView(request, eda_variable, eda_variable2):
    
    model = globals()[request.session['model']]
    
    plt.clf()
    
    if ("GET" == request.method):
    
        # get first column of data form the database
        data = model.objects.values_list(eda_variable)
        data_list = []

        # Logger set up
        logger = logging.getLogger('app_api')

        # Guess if first variable is numerical or not
        numeric = False

        if (str(type(data[0][0])) == "<class 'decimal.Decimal'>"):
            numeric = True

        # Build a list with the data and its cirrect type
        if (numeric):
            for element in data:
                data_list.append(float(element[0]))
        else:
            for element in data:
                data_list.append(str(element[0]))

        ########## Univariate analysis ##########

        # If second variable's string is equal to '0', run univariate analysis 
        if (eda_variable2 == str(0)):

            # Get the rest of variables to use them as parameter for the bivariate analysis
            fields_ini = model._meta.fields
            fields = []

            for variable in fields_ini:
                position = stringfunctions.find_nth(str(variable), '.', 2)
                var_name = str(variable)[position+1:]

                if (str(eda_variable) != var_name):
                    fields.append((var_name,var_name))

            # create the form for the bivariate analysis
            form = EdaBivariableForm()
            form.select_eda_variable(fields)

            # Univariate numeric analysis
            if numeric:

                # Call the univariate numeric analysis function and store all the variables correctly
                missing_values_image, histogram, mean, median, mode, quantiles, stdev, variance, max_value, min_value, Range, IQR, box_plot_image, QQplot_image, sw_test, skewness_test, kurtosis_test = eda.univariate_numeric(eda_variable, data_list, False, '')

                return render(request, "bdmed/eda_numeric.html", {'data': data, 'missing_values_image': missing_values_image, 'histogram': histogram,
                                                         'mean': mean, 'median': median, 'mode': mode, 'quantiles': quantiles, 'stdev': stdev,
                                                         'variance': variance, 'max_value': max_value, 'min_value': min_value, 'range': Range,
                                                         'IQR': IQR, 'box_plot_image': box_plot_image, 'QQplot_image': QQplot_image,
                                                         'sw_test': sw_test, 'skewness_test': skewness_test, 'kurtosis_test': kurtosis_test,
                                                         'form': form, 'eda_variable': eda_variable, 'model':request.session['model']})

            # Univariate categorical analysis
            else:                

                # Call the univariate categorical analysis function and store all the variables correctly
                missing_values_image, bar_plot_image, frequencies_absolute, frequencies_relative = eda.univariate_categorical(eda_variable, data_list)
                
                frequencies = pd.DataFrame()
                frequencies["Tipos"] =  list(frequencies_absolute.keys())
                frequencies["Absoluta"] =  list(frequencies_absolute.values())
                frequencies["Relativa"] =  list(frequencies_relative.values())
                
                logger.info(frequencies)
                logger.info(frequencies.to_dict())
                
                return render(request, "bdmed/eda_categorical.html", {'data': data, 'missing_values_image': missing_values_image,
                                                                     'bar_plot_image': bar_plot_image, 'frequencies': frequencies,
                                                                     'form': form, 'eda_variable': eda_variable, 'model':request.session['model']})

       ########## Bivariate analysis ##########
        else:

            # get second column of data form the database
            data2 = model.objects.values_list(eda_variable2)

            # declaer the list where the secon column values will be at
            data_list2 = []

            # Check if this second variable is numerical or categorical
            numeric2 = False
            if (str(type(data2[0][0])) == "<class 'decimal.Decimal'>"):
                numeric2 = True

            # 3 different possibilities

            # Both numerical
            if (numeric and numeric2):

                # Build the list with the second numerical column of data
                for element in data2:
                        data_list2.append(float(element[0]))


                # Call the bivariate numerical-numerical analysis function and store all the variables correctly
                scatter_plot, Pearson_coeff = eda.bivariate_numeric(data_list, data_list2)

                return render (request, "bdmed/eda_numeric_numeric.html", {'scatter_plot':scatter_plot, 'Pearson_coeff':Pearson_coeff, 
                                                                           'eda_variable':eda_variable, 'eda_variable2':eda_variable2, 'model':request.session['model']})

            # Numerical and categorical 
            elif ((not(numeric) and numeric2) or (numeric and not(numeric2))):

                #  Call the bivariate numerical-categorical analysis function and store all the variables correctly  
                histogram_list, mean_list, median_list, mode_list, quantiles_list, stdev_list, variance_list, max_value_list, min_value_list, Range_list, IQR_list, box_plot_list, sw_list = eda.bivariate_numeric_categorical(eda_variable, eda_variable2, numeric, numeric2, data, data2, model)

                return render (request, "bdmed/eda_numeric_categorical.html", {'histogram_list':histogram_list, 'mean_list': mean_list, 
                                                                               'median_list': median_list, 'mode_list': mode_list,
                                                                               'quantiles_list': quantiles_list, 'stdev_list': stdev_list,
                                                                               'variance_list': variance_list, 'max_value_list': max_value_list,
                                                                               'min_value_list': min_value_list, 'range_list': Range_list,
                                                                               'IQR_list': IQR_list, 'box_plot_list': box_plot_list,
                                                                               'sw_list': sw_list, 'eda_variable': eda_variable, 'model':request.session['model']})

            # Both categorical
            else:

                # Build the list with the second categorical column of data
                for element2 in data2:
                    data_list2.append(str(element2[0]))

                # Call the bivariate categorical-categorical analysis function and store all the variables correctly
                data_crosstab_df, chi2, bar_plot_2cat_image = eda.bivariate_categorical(data_list, data_list2)

                return render(request, "bdmed/eda_categorical_categorical.html", {'data_crosstab_df':data_crosstab_df, 'chi2':chi2,
                                                                                 'bar_plot_2cat_image': bar_plot_2cat_image, 'eda_variable':eda_variable, 'eda_variable2':eda_variable2,
                                                                                 'model':request.session['model']})
            
    else:
            
        # Get the variable for the bivariate analysis and set the parametes
        variable = request.POST.getlist('Variable')

        return HttpResponseRedirect(reverse('bdmed:eda', args=[eda_variable, variable[0]]))

        
# View to select the variables for running the big data algorithm
def SelectVariableView(request):
        
    data = {}
    model_sf = globals()[request.session['model'] + "SelectionForm"]

    if ("GET" == request.method):
        
        form = model_sf()
        
        return render(request, "bdmed/select_variable.html", {'form': form, 'model':request.session['model']})
    
    # if not get, then POST 
    else:
       
        # create a form instance and populate it with data from the request:
        form = model_sf(request.POST)
        # check whether it's valid:
        if form.is_valid():
            
            # For the classification algorithms view
            request.session['variables_classification'] = form.cleaned_data
            
            return HttpResponseRedirect(reverse("bdmed:select_target"))
        
def SelectTargetView(request):
        
    possible_targets = globals()[request.session['model'] + "_CHOICES"]

    if ("GET" == request.method):
        
        form = TargetForm()
        form.create_target(possible_targets)
        
        return render(request, "bdmed/select_target.html", {'form': form, 'model':request.session['model']})
    
    # if not get, then POST 
    else:
       
        # create a form instance and populate it with data from the request:
        form = TargetFormChar(request.POST)
        
        # check whether it's valid:
        if form.is_valid():
            
            # For the classification algorithms view
            request.session['target'] = form.cleaned_data
            
            return HttpResponseRedirect(reverse("bdmed:cluster_set_up"))

def ProblemResolutionView(request):
    
    template = loader.get_template('bdmed/problem_resolution.html')
    
    return render (request, "bdmed/problem_resolution.html", {'Regression':'Regression'})

def ClassificationView(request):
    
    template = loader.get_template('bdmed/classification.html')
    
    return render (request, "bdmed/classification.html", {'Binary_Classification': 'Binary_Classification', 'Multiclass_Classification':'Multiclass_Classification' })
    
    
def AlgorithmSelectionView(request, problem_string):
    
    if ("GET" == request.method):
        
        if (problem_string == "Binary_Classification"):
            
            # Get the form to select one binary classification algorithm 
            form = BinaryClassificationAlgorithmSelectionForm()
            
        elif (problem_string == "Multiclass_Classification"):
            
            # Get the form to select one multiclass classification algorithm 
            form = MulticlassClassificationAlgorithmSelectionForm()
            
        elif (problem_string == "Regression"):
        
            # Get the form to select one regression algorithm 
            form = RegressionAlgorithmSelectionForm()
        
        return render (request, "bdmed/algorithm_selection.html", {'form':form, 'problem_string':problem_string})
        
    else:
        
        # create a form instance and populate it with data from the request:
        
        if (problem_string == "Binary_Classification"):
            
            form = BinaryClassificationAlgorithmSelectionFormChar(request.POST)
            
        elif (problem_string == "Multiclass_Classification"):
            
            form = MulticlassClassificationAlgorithmSelectionFormChar(request.POST)
            
        elif (problem_string == "Regression"):
        
            form = RegressionAlgorithmSelectionFormChar(request.POST)
        
        # check whether it's valid:
        if form.is_valid():
            
            request.session['selected_algorithm'] = form.cleaned_data['Algorithm']
            
            return HttpResponseRedirect(reverse("bdmed:select_variable"))
    
def AlgorithmSetUpView(request):
    
    model = globals()[request.session['model']]
    logger = logging.getLogger('app_api')
    
    # If an algorithm has been previously selected
    if (request.session.get('selected_algorithm', None)):
        
        # If its a get method,  and show the selected algorithm's form
        if ("GET" == request.method):
        
            # Select parameters for the selected algorithm

            if (request.session['selected_algorithm'] == "BinaryLogisticRegression" or request.session['selected_algorithm'] == "MulticlassLogisticRegression"):
                form = LogisticRegressionForm()
                
            elif (request.session['selected_algorithm'] == "BinaryDecisionTree" or request.session['selected_algorithm'] == "MulticlassDecisionTree"):                
                form = DecisionTreeForm()
                
            elif (request.session['selected_algorithm'] == "BinaryRandomForest" or request.session['selected_algorithm'] == "MulticlassRandomForest"):                
                form = RandomForestForm()
                
            elif (request.session['selected_algorithm'] == "BinaryGBT"):                
                form = GBTForm()
                
            elif (request.session['selected_algorithm'] == "BinaryNaiveBayes" or request.session['selected_algorithm'] == "MulticlassNaiveBayes"):                
                form = NaiveBayesForm()
                
            elif (request.session['selected_algorithm'] == "BinaryLinearSVC"):
                form = LinearSVCForm()
                
            elif (request.session['selected_algorithm'] == "DecisionTreeRegression"):
                form = DecisionTreeRegressionForm()
            
            elif(request.session['selected_algorithm'] == "RandomForestRegression"):
                form = RandomForestRegressionForm()
                
            elif(request.session['selected_algorithm'] == "GBTRegression"):
                form = GBTRegressionForm()
        
            return render(request, "bdmed/algorithm_set_up.html", {'form': form, 'selected_algorithm':request.session['selected_algorithm'], 'model':request.session['model']})
        
        # If it is a post method build the spark dataframe and run the algorithms
        else:
            
            ############# Build pyspark dataframe with the selected variables #############

            # get the variables selected for the classification
            variables = request.session['variables_classification']

            # create a pandas df with the required elements
            df = pd.DataFrame()

            # list of categorical/numerical variables
            variables_numeric = []
            variables_categoric = []
            target_variable = ''

            # iterate and check the selected variables
            for variable in variables:

                # if it is selected
                if (variables[variable] == True):

                    selected_text = variable
                    
                    # select its type
                    variable_type =  model._meta.get_field(variable).get_internal_type()
                        

                    # check type of variable and add it to the correct list
                    if (variable_type == "DecimalField"):

                        df[variable] = list(map(float, [i[0] for i in list(model.objects.values_list(selected_text))]))
                        variables_numeric.append(variable)

                    else:
                        
                        df[variable] = list(map(str, [i[0] for i in list(model.objects.values_list(selected_text))]))
                        variables_categoric.append(variable)
                            
            # Check target variable and select its type
            target_variable = request.session['target']['Target']
            target_variable_cut = target_variable[0:-6]
            target_variable_type = model._meta.get_field(target_variable_cut).get_internal_type()
            
            # Add it to the dataframe
            if (target_variable_type == "DecimalField"):

                df[target_variable] = list(map(float, [i[0] for i in list(model.objects.values_list(target_variable_cut))]))

            else:
                      
                df[target_variable] = list(map(str, [i[0] for i in list(model.objects.values_list(target_variable_cut))]))
                            
            # shuffle dataset rows
            df = df.sample(frac=1).reset_index(drop=True)

            # create spark session
            
            # local spark session (using all the cores and a single executor)
            if (request.session['Distributed'] == False):
                spark = SparkSession.builder.getOrCreate()
            
            # distributed spark session, with the configuration from the ClusterSetUp view
            else:
                conf = SparkConf().setMaster(request.session['ConexionToSparkMaster']).setAppName("Bdmed")
                conf.set("spark.cores.max", str(request.session['NumberOfCores']))
                conf.set("spark.executor.cores", str(request.session['NumberOfCoresPerExecutor']))
                conf.set("spark.executor.memory", str(request.session['ExecutorMemory'])+'g')
                
                spark = SparkSession.builder.config(conf = conf).appName("Distributed execution of " + request.session['selected_algorithm'] + " algorithm, using model " + request.session['model']).getOrCreate()
            
            #check deatils of configuration
            sc = spark.sparkContext
            logger.info(sc.getConf().getAll())
            
            # create pyspark dataframe from pandas' one        
            pyspark_df = spark.createDataFrame(df) 

            # apply classification preprocessing (get labels and features in the correct format for algorithms)
            if (request.session['selected_algorithm'] == "DecisionTreeRegression" or request.session['selected_algorithm'] == "RandomForestRegression" or request.session['selected_algorithm'] == "GBTRegression"):
                preprocessed_df = sparkpreprocessing.classification_preprocessing(variables_numeric, variables_categoric,
                                                                              target_variable, pyspark_df, "Regression")
            else:
                preprocessed_df = sparkpreprocessing.classification_preprocessing(variables_numeric, variables_categoric,
                                                                              target_variable, pyspark_df, "Classification")
            
                # get the variable mapping done by the preprocessing
                tv1 = list(pd.unique(preprocessed_df.select(target_variable).toPandas()[target_variable]))
                tv2 = list(pd.unique(preprocessed_df.select('label').toPandas()['label']))
                tv_map = dict(zip(tv2,tv1))
                logger.info("mapeo de variable target y labels finales tras el preprocesamiento de pyspark")
                logger.info(tv_map)

            # Get String with schema and 20 first lines and the shape of the pyspark dataframe

            # get schema
            g = StringIO()

            with redirect_stdout(g):
                preprocessed_df.printSchema()

            df_schema = g.getvalue()
            
            # get 20 first lines of the dataframe
            f = StringIO()

            with redirect_stdout(f):
                preprocessed_df.show(20)

            df_show = f.getvalue()
            
            # get shape
            df_shape = str(preprocessed_df.count()) + " x " + str(len(preprocessed_df.columns))
            
            logger.info("full df_show")
            logger.info(preprocessed_df.show(truncate=False,n=150))
            
            # begin to count the execution time of the algorithm
            start_time = time.time()
            
            #check which is the selected algorithm
            
            if (request.session['selected_algorithm'] == "BinaryLogisticRegression"):
                
                # Get the algorithm's parameters
                form = LogisticRegressionForm(request.POST)
                
                # check whether it's valid:
                if form.is_valid():
                
                    # Run Algorithm
                    num_folds, AUC_mean, coeff, AUC_best, accuracy_best, ROC_best, PR_best, coeff_image, ROC_image, PR_image = sparkclassificationalgorithms.binary_log_regression_classifier_cv(
                        preprocessed_df, form.cleaned_data['maxIter'], form.cleaned_data['parallelism'], form.cleaned_data['nfolds'])
                    
                    # Create result and store it in the database
                    result_instance = BinaryLogisticRegressionResult.objects.create(maxIter = form.cleaned_data['maxIter'], parallelism = form.cleaned_data['parallelism'],
                                                                                    numFolds = form.cleaned_data['nfolds'], dfSchema = df_schema, dfShape = df_shape,
                                                                                    AUCMean = AUC_mean[0], AUCBest = AUC_best , AccuracyBest = accuracy_best,
                                                                                    CoeffImage = coeff_image, ROCImage = ROC_image,  PRImage = PR_image, dfShow = df_show,
                                                                                    model = request.session['model'], executionTime = str(time.time() - start_time))
                    
            elif (request.session['selected_algorithm'] == "MulticlassLogisticRegression"):
                
                # Get the algorithm's parameters, same as binary
                form = LogisticRegressionForm(request.POST)
                
                # check whether it's valid:
                if form.is_valid():

                    # Run Algorithm
                    num_folds, F1_mean, coeff_matrix, accuracy_best, F1_by_label, FPR_by_label, TPR_by_label, precision_by_label, recall_by_label, F1_weighted, FPR_weighted, TPR_weighted, precision_weighted, recall_weighted = sparkclassificationalgorithms.multiclass_log_regression_classifier_cv(
                        preprocessed_df, form.cleaned_data['maxIter'], form.cleaned_data['parallelism'], form.cleaned_data['nfolds'])
                    
                    # Create result and store it in the database
                    result_instance = MulticlassLogisticRegressionResult.objects.create(maxIter = form.cleaned_data['maxIter'], parallelism = form.cleaned_data['parallelism'],
                                                                                    numFolds = form.cleaned_data['nfolds'], dfSchema = df_schema, dfShape = df_shape,
                                                                                    coeffMatrix = str(coeff_matrix), accuracyBest = accuracy_best , F1ByLabel = str(F1_by_label),
                                                                                    FPRByLabel = str(FPR_by_label), TPRByLabel = str(TPR_by_label),  precisionByLabel = str(precision_by_label),
                                                                                    recallByLabel = str(recall_by_label), F1Weighted = F1_weighted, FPRWeighted = FPR_weighted, 
                                                                                    TPRWeighted = TPR_weighted, precisionWeighted = precision_weighted, recallWeighted = recall_weighted,
                                                                                    F1Mean = F1_mean[0], dfShow = df_show, model = request.session['model'], executionTime = str(time.time() - start_time))
                
            elif (request.session['selected_algorithm'] == "BinaryDecisionTree"):
                
                # Get the algorithm's parameters
                form = DecisionTreeFormChar(request.POST)
                
                # check whether it's valid:
                if form.is_valid():
                
                    # Run Algorithm
                    num_folds, AUC_mean, AUC_best, accuracy, cm, cm_norm, precision_0, recall_0, FPR_0, TNR_0, F1_0, precision_1, recall_1, FPR_1, TNR_1, F1_1, ROC_image_0, ROC_image_1 = sparkclassificationalgorithms.binary_classifiers(algorithm_param = "BinaryDecisionTree", df = preprocessed_df, parallelism_param = form.cleaned_data['parallelism'],
                    n_folds_param = form.cleaned_data['nfolds'], max_depth_param = form.cleaned_data['maxDepth'], max_bins_param = form.cleaned_data['maxBins'],
                    min_instances_per_node_param = form.cleaned_data['minInstancesPerNode'], min_info_gain_param = form.cleaned_data['minInfoGain'],
                    max_memory_in_mb_param = form.cleaned_data['maxMemoryInMB'], impurity_param = form.cleaned_data['impurity'], tv_map_param = tv_map)
                    
                    # Create result and store it in the database
                    result_instance = BinaryDecisionTreeResult.objects.create(parallelism = form.cleaned_data['parallelism'],
                                                                              numFolds = form.cleaned_data['nfolds'], dfSchema = df_schema, dfShape = df_shape, 
                                                                              dfShow = df_show, labelMapping = str(tv_map), maxDepth = form.cleaned_data['maxDepth'], 
                                                                              maxBins = form.cleaned_data['maxBins'], minInstancesPerNode = form.cleaned_data['minInstancesPerNode'],
                                                                              minInfoGain = form.cleaned_data['minInfoGain'], maxMemoryInMB = form.cleaned_data['maxMemoryInMB'],
                                                                              impurity = form.cleaned_data['impurity'], AUCMean = AUC_mean[0], AUCBest = AUC_best,
                                                                              AccuracyBest = accuracy, CMBest = str(cm), CMNormBest = str(cm_norm), PrecisionBest_0 = precision_0,
                                                                              RecallBest_0 = recall_0, FPRBest_0 = FPR_0, TNRBest_0 = TNR_0, F1Score_0 = F1_0, ROCImage_0 = ROC_image_0,
                                                                              PrecisionBest_1 = precision_1, RecallBest_1 = recall_1, FPRBest_1 = FPR_1, TNRBest_1 = TNR_1,
                                                                              F1Score_1 = F1_1, ROCImage_1 = ROC_image_1, model = request.session['model'], executionTime = str(time.time() - start_time))
            
            elif (request.session['selected_algorithm'] == "MulticlassDecisionTree"):
                
                # Get the algorithm's parameters - it's the same as binary form
                form = DecisionTreeFormChar(request.POST)
                
                # check whether it's valid:
                if form.is_valid():
                
                    # Run Algorithm
                    num_folds, F1_mean, cm, cm_norm, accuracy, precision_by_label, recall_by_label, TNR_by_label, FPR_by_label, F1_by_label, precision_weighted, recall_weighted, TNR_weighted, FPR_weighted, F1_weighted = sparkclassificationalgorithms.multiclass_classifiers(algorithm_param = "MulticlassDecisionTree", df = preprocessed_df, 
                    parallelism_param = form.cleaned_data['parallelism'], n_folds_param = form.cleaned_data['nfolds'], max_depth_param = form.cleaned_data['maxDepth'],
                    max_bins_param = form.cleaned_data['maxBins'], min_instances_per_node_param = form.cleaned_data['minInstancesPerNode'],
                    min_info_gain_param = form.cleaned_data['minInfoGain'], max_memory_in_mb_param = form.cleaned_data['maxMemoryInMB'], impurity_param = form.cleaned_data['impurity'])
                    
                    # Create result and store it in the database
                    result_instance = MulticlassDecisionTreeResult.objects.create(numFolds = form.cleaned_data['nfolds'], dfSchema = df_schema, dfShape = df_shape, dfShow = df_show,
                                                                                  labelMapping = str(tv_map), maxDepth = form.cleaned_data['maxDepth'], maxBins = form.cleaned_data['maxBins'],
                                                                                  minInstancesPerNode = form.cleaned_data['minInstancesPerNode'],
                                                                                  minInfoGain = form.cleaned_data['minInfoGain'], maxMemoryInMB = form.cleaned_data['maxMemoryInMB'], 
                                                                                  impurity = form.cleaned_data['impurity'], accuracyBest = accuracy, F1ByLabel = str(F1_by_label), 
                                                                                  FPRByLabel = str(FPR_by_label), TNRByLabel = str(TNR_by_label),  precisionByLabel = str(precision_by_label),
                                                                                  recallByLabel = str(recall_by_label), F1Weighted = F1_weighted, FPRWeighted = FPR_weighted, 
                                                                                  TNRWeighted = TNR_weighted, precisionWeighted = precision_weighted, recallWeighted = recall_weighted,
                                                                                  F1Mean = F1_mean[0], CMBest = cm, CMNormBest = cm_norm, parallelism = form.cleaned_data['parallelism'],
                                                                                  model = request.session['model'], executionTime = str(time.time() - start_time))
            
            elif (request.session['selected_algorithm'] == "BinaryRandomForest"):
                
                # Get the algorithm's parameters
                form = RandomForestFormChar(request.POST)
                
                # check whether it's valid:
                if form.is_valid():
                
                    # Run Algorithm
                    num_folds, AUC_mean, AUC_best, accuracy, cm, cm_norm, precision_0, recall_0, FPR_0, TNR_0, F1_0, precision_1, recall_1, FPR_1, TNR_1, F1_1, ROC_image_0, ROC_image_1 = sparkclassificationalgorithms.binary_classifiers(algorithm_param = "BinaryRandomForest", df = preprocessed_df, parallelism_param = form.cleaned_data['parallelism'],
                    n_folds_param = form.cleaned_data['nfolds'], max_depth_param = form.cleaned_data['maxDepth'], max_bins_param = form.cleaned_data['maxBins'],
                    min_instances_per_node_param = form.cleaned_data['minInstancesPerNode'], min_info_gain_param = form.cleaned_data['minInfoGain'],
                    max_memory_in_mb_param = form.cleaned_data['maxMemoryInMB'], impurity_param = form.cleaned_data['impurity'], tv_map_param = tv_map,
                    subsamplingRate_param = form.cleaned_data['subsamplingRate'] , featureSubsetStrategy_param = form.cleaned_data['featureSubsetStrategy'], 
                    numTrees_param = form.cleaned_data['numTrees'], bootstrap_param = form.cleaned_data['bootstrap'])
                    
                    # Create result and store it in the database
                    result_instance = BinaryRandomForestResult.objects.create(parallelism = form.cleaned_data['parallelism'],
                                                                              numFolds = form.cleaned_data['nfolds'], dfSchema = df_schema, dfShape = df_shape, 
                                                                              dfShow = df_show, labelMapping = str(tv_map), maxDepth = form.cleaned_data['maxDepth'], 
                                                                              maxBins = form.cleaned_data['maxBins'], minInstancesPerNode = form.cleaned_data['minInstancesPerNode'],
                                                                              minInfoGain = form.cleaned_data['minInfoGain'], maxMemoryInMB = form.cleaned_data['maxMemoryInMB'],
                                                                              impurity = form.cleaned_data['impurity'], subsamplingRate = form.cleaned_data['subsamplingRate'] , 
                                                                              featureSubsetStrategy = form.cleaned_data['featureSubsetStrategy'], numTrees = form.cleaned_data['numTrees'],
                                                                              bootstrap = form.cleaned_data['bootstrap'], AUCMean = AUC_mean[0], AUCBest = AUC_best,
                                                                              AccuracyBest = accuracy, CMBest = str(cm), CMNormBest = str(cm_norm), PrecisionBest_0 = precision_0,
                                                                              RecallBest_0 = recall_0, FPRBest_0 = FPR_0, TNRBest_0 = TNR_0, F1Score_0 = F1_0, ROCImage_0 = ROC_image_0,
                                                                              PrecisionBest_1 = precision_1, RecallBest_1 = recall_1, FPRBest_1 = FPR_1, TNRBest_1 = TNR_1,
                                                                              F1Score_1 = F1_1, ROCImage_1 = ROC_image_1, model = request.session['model'], executionTime = str(time.time() - start_time))
            
            elif (request.session['selected_algorithm'] == "MulticlassRandomForest"):
                
                # Get the algorithm's parameters - it's the same as multiclass form
                form = RandomForestFormChar(request.POST)
                
                # check whether it's valid:
                if form.is_valid():
                
                    # Run Algorithm
                    num_folds, F1_mean, cm, cm_norm, accuracy, precision_by_label, recall_by_label, TNR_by_label, FPR_by_label, F1_by_label, precision_weighted, recall_weighted, TNR_weighted, FPR_weighted, F1_weighted = sparkclassificationalgorithms.multiclass_classifiers(algorithm_param = "MulticlassRandomForest", df = preprocessed_df, 
                    parallelism_param = form.cleaned_data['parallelism'], n_folds_param = form.cleaned_data['nfolds'], max_depth_param = form.cleaned_data['maxDepth'], 
                    max_bins_param = form.cleaned_data['maxBins'], min_instances_per_node_param = form.cleaned_data['minInstancesPerNode'], 
                    min_info_gain_param = form.cleaned_data['minInfoGain'], max_memory_in_mb_param = form.cleaned_data['maxMemoryInMB'], impurity_param = form.cleaned_data['impurity'],
                    subsamplingRate_param = form.cleaned_data['subsamplingRate'] , featureSubsetStrategy_param = form.cleaned_data['featureSubsetStrategy'], 
                    numTrees_param = form.cleaned_data['numTrees'], bootstrap_param = form.cleaned_data['bootstrap'])
                    
                    # Create result and store it in the database
                    result_instance = MulticlassRandomForestResult.objects.create(numFolds = form.cleaned_data['nfolds'], dfSchema = df_schema, dfShape = df_shape, dfShow = df_show,
                                                                                  labelMapping = str(tv_map), maxDepth = form.cleaned_data['maxDepth'], maxBins = form.cleaned_data['maxBins'],
                                                                                  minInstancesPerNode = form.cleaned_data['minInstancesPerNode'],
                                                                                  minInfoGain = form.cleaned_data['minInfoGain'], maxMemoryInMB = form.cleaned_data['maxMemoryInMB'], 
                                                                                  impurity = form.cleaned_data['impurity'],subsamplingRate = form.cleaned_data['subsamplingRate'] ,
                                                                                  featureSubsetStrategy = form.cleaned_data['featureSubsetStrategy'], numTrees = form.cleaned_data['numTrees'],
                                                                                  bootstrap = form.cleaned_data['bootstrap'], accuracyBest = accuracy, F1ByLabel = str(F1_by_label), 
                                                                                  FPRByLabel = str(FPR_by_label), TNRByLabel = str(TNR_by_label),  precisionByLabel = str(precision_by_label),
                                                                                  recallByLabel = str(recall_by_label), F1Weighted = F1_weighted, FPRWeighted = FPR_weighted, 
                                                                                  TNRWeighted = TNR_weighted, precisionWeighted = precision_weighted, recallWeighted = recall_weighted,
                                                                                  F1Mean = F1_mean[0], CMBest = cm, CMNormBest = cm_norm, parallelism = form.cleaned_data['parallelism'],
                                                                                  model = request.session['model'], executionTime = str(time.time() - start_time))
                    
            elif(request.session['selected_algorithm'] == "BinaryGBT"):
    
                # Get the algorithm's parameters - it's the same as multiclass form
                form = GBTFormChar(request.POST)
                
                # check whether it's valid:
                if form.is_valid():
                
                    # Run Algorithm
                    num_folds, AUC_mean, AUC_best, accuracy, cm, cm_norm, precision_0, recall_0, FPR_0, TNR_0, F1_0, precision_1, recall_1, FPR_1, TNR_1, F1_1 = sparkclassificationalgorithms.binary_classifiers(algorithm_param = "BinaryGBT", df = preprocessed_df, parallelism_param = form.cleaned_data['parallelism'],
                    n_folds_param = form.cleaned_data['nfolds'], max_depth_param = form.cleaned_data['maxDepth'], max_bins_param = form.cleaned_data['maxBins'],
                    min_instances_per_node_param = form.cleaned_data['minInstancesPerNode'], min_info_gain_param = form.cleaned_data['minInfoGain'],
                    max_memory_in_mb_param = form.cleaned_data['maxMemoryInMB'], impurity_param = form.cleaned_data['impurity'], tv_map_param = tv_map,
                    subsamplingRate_param = form.cleaned_data['subsamplingRate'] , featureSubsetStrategy_param = form.cleaned_data['featureSubsetStrategy'], 
                    maxIter_param = form.cleaned_data['maxIter'], lossType_param = form.cleaned_data['lossType'], validationTol_param = form.cleaned_data['validationTol'],
                    stepSize_param = form.cleaned_data['stepSize'], minWeightFractionPerNode_param = form.cleaned_data['minWeightFractionPerNode'])
                    
                    # Create result and store it in the database
                    result_instance = BinaryGBTResult.objects.create(parallelism = form.cleaned_data['parallelism'],
                                                                              numFolds = form.cleaned_data['nfolds'], dfSchema = df_schema, dfShape = df_shape, 
                                                                              dfShow = df_show, labelMapping = str(tv_map), maxDepth = form.cleaned_data['maxDepth'], 
                                                                              maxBins = form.cleaned_data['maxBins'], minInstancesPerNode = form.cleaned_data['minInstancesPerNode'],
                                                                              minInfoGain = form.cleaned_data['minInfoGain'], maxMemoryInMB = form.cleaned_data['maxMemoryInMB'],
                                                                              impurity = form.cleaned_data['impurity'], subsamplingRate = form.cleaned_data['subsamplingRate'] , 
                                                                              featureSubsetStrategy = form.cleaned_data['featureSubsetStrategy'], maxIter = form.cleaned_data['maxIter'],
                                                                              lossType = form.cleaned_data['lossType'], validationTol = form.cleaned_data['validationTol'],
                                                                              stepSize = form.cleaned_data['stepSize'], minWeightFractionPerNode = form.cleaned_data['minWeightFractionPerNode'],
                                                                              AUCMean = AUC_mean[0], AUCBest = AUC_best,
                                                                              AccuracyBest = accuracy, CMBest = str(cm), CMNormBest = str(cm_norm), PrecisionBest_0 = precision_0,
                                                                              RecallBest_0 = recall_0, FPRBest_0 = FPR_0, TNRBest_0 = TNR_0, F1Score_0 = F1_0,
                                                                              PrecisionBest_1 = precision_1, RecallBest_1 = recall_1, FPRBest_1 = FPR_1, TNRBest_1 = TNR_1,
                                                                              F1Score_1 = F1_1, model = request.session['model'], executionTime = str(time.time() - start_time))
                    
            elif(request.session['selected_algorithm'] == "BinaryNaiveBayes"):
    
                # Get the algorithm's parameters - it's the same as multiclass form
                form = NaiveBayesFormChar(request.POST)
                
                # check whether it's valid:
                if form.is_valid():
                
                    # Run Algorithm
                    num_folds, AUC_mean, AUC_best, accuracy, cm, cm_norm, precision_0, recall_0, FPR_0, TNR_0, F1_0, precision_1, recall_1, FPR_1, TNR_1, F1_1, ROC_image_0, ROC_image_1 = sparkclassificationalgorithms.binary_classifiers(algorithm_param = "BinaryNaiveBayes", df = preprocessed_df, parallelism_param = form.cleaned_data['parallelism'],
                    n_folds_param = form.cleaned_data['nfolds'],  tv_map_param = tv_map, smoothing_param = form.cleaned_data['smoothing'] , modelType_param = form.cleaned_data['modelType'])
                    
                    # Create result and store it in the database
                    result_instance = BinaryNaiveBayesResult.objects.create(parallelism = form.cleaned_data['parallelism'],
                                                                              numFolds = form.cleaned_data['nfolds'], dfSchema = df_schema, dfShape = df_shape, 
                                                                              dfShow = df_show, labelMapping = str(tv_map), smoothing = form.cleaned_data['smoothing'], 
                                                                              modelType = form.cleaned_data['modelType'], AUCMean = AUC_mean[0], AUCBest = AUC_best,
                                                                              AccuracyBest = accuracy, CMBest = str(cm), CMNormBest = str(cm_norm), PrecisionBest_0 = precision_0,
                                                                              RecallBest_0 = recall_0, FPRBest_0 = FPR_0, TNRBest_0 = TNR_0, F1Score_0 = F1_0,
                                                                              PrecisionBest_1 = precision_1, RecallBest_1 = recall_1, FPRBest_1 = FPR_1, TNRBest_1 = TNR_1,
                                                                              F1Score_1 = F1_1, ROCImage_0 = ROC_image_0, ROCImage_1 = ROC_image_1, model = request.session['model'],
                                                                              executionTime = str(time.time() - start_time))
            
            elif(request.session['selected_algorithm'] == "MulticlassNaiveBayes"):
    
                # Get the algorithm's parameters - it's the same as multiclass form
                form = NaiveBayesFormChar(request.POST)
                
                # check whether it's valid:
                if form.is_valid():
                
                    # Run Algorithm
                    num_folds, F1_mean, cm, cm_norm, accuracy, precision_by_label, recall_by_label, TNR_by_label, FPR_by_label, F1_by_label, precision_weighted, recall_weighted, TNR_weighted, FPR_weighted, F1_weighted = sparkclassificationalgorithms.multiclass_classifiers(algorithm_param = "MulticlassNaiveBayes", df = preprocessed_df, 
                    parallelism_param = form.cleaned_data['parallelism'], n_folds_param = form.cleaned_data['nfolds'], smoothing_param = form.cleaned_data['smoothing'] ,
                    modelType_param = form.cleaned_data['modelType'])
                    
                    # Create result and store it in the database
                    result_instance = MulticlassNaiveBayesResult.objects.create(numFolds = form.cleaned_data['nfolds'], dfSchema = df_schema, dfShape = df_shape, dfShow = df_show,
                                                                                  labelMapping = str(tv_map), smoothing = form.cleaned_data['smoothing'], 
                                                                                  modelType = form.cleaned_data['modelType'], accuracyBest = accuracy, F1ByLabel = str(F1_by_label), 
                                                                                  FPRByLabel = str(FPR_by_label), TNRByLabel = str(TNR_by_label),  precisionByLabel = str(precision_by_label),
                                                                                  recallByLabel = str(recall_by_label), F1Weighted = F1_weighted, FPRWeighted = FPR_weighted, 
                                                                                  TNRWeighted = TNR_weighted, precisionWeighted = precision_weighted, recallWeighted = recall_weighted,
                                                                                  F1Mean = F1_mean[0], CMBest = cm, CMNormBest = cm_norm, parallelism = form.cleaned_data['parallelism'],
                                                                                  model = request.session['model'], executionTime = str(time.time() - start_time))
                    
            elif (request.session['selected_algorithm'] == "BinaryLinearSVC"):
                
                # Get the algorithm's parameters - it's the same as multiclass form
                form = LinearSVCForm(request.POST)
                
                # check whether it's valid:
                if form.is_valid():
                
                     # Run Algorithm
                    num_folds, AUC_mean, AUC_best, accuracy, cm, cm_norm, precision_0, recall_0, FPR_0, TNR_0, F1_0, precision_1, recall_1, FPR_1, TNR_1, F1_1 = sparkclassificationalgorithms.binary_classifiers(algorithm_param = "BinaryLinearSVC", df = preprocessed_df, parallelism_param = form.cleaned_data['parallelism'], 
                    n_folds_param = form.cleaned_data['nfolds'],  tv_map_param = tv_map, maxIter_param = form.cleaned_data['maxIter'] , aggregationDepth_param = form.cleaned_data['aggregationDepth'],
                    regParam_param = form.cleaned_data['regParam'], standardization_param = form.cleaned_data['standardization'],
                    tol_param = form.cleaned_data['tol'])
                    
                    # Create result and store it in the database
                    result_instance = BinaryLinearSVCResult.objects.create(parallelism = form.cleaned_data['parallelism'],
                                                                           numFolds = form.cleaned_data['nfolds'], dfSchema = df_schema, dfShape = df_shape, 
                                                                           dfShow = df_show, labelMapping = str(tv_map),  maxIter = form.cleaned_data['maxIter'],
                                                                           aggregationDepth = form.cleaned_data['aggregationDepth'], regParam = form.cleaned_data['regParam'],
                                                                           standardization = form.cleaned_data['standardization'], tol = form.cleaned_data['tol'], AUCMean = AUC_mean[0],
                                                                           AUCBest = AUC_best, AccuracyBest = accuracy, CMBest = str(cm), CMNormBest = str(cm_norm), PrecisionBest_0 = precision_0,
                                                                           RecallBest_0 = recall_0, FPRBest_0 = FPR_0, TNRBest_0 = TNR_0, F1Score_0 = F1_0,
                                                                           PrecisionBest_1 = precision_1, RecallBest_1 = recall_1, FPRBest_1 = FPR_1, TNRBest_1 = TNR_1,
                                                                           F1Score_1 = F1_1, model = request.session['model'], executionTime = str(time.time() - start_time))
                    
            
            
            elif (request.session['selected_algorithm'] == "DecisionTreeRegression"):
                
                # Get the regression algorithm's parameters
                form = DecisionTreeFormChar(request.POST)
                
                # check whether it's valid:
                if form.is_valid():
                    
                    # Run Algorithm
                    num_folds, RMSE_Mean, MAE_Best, MAPE_Best, MSE_Best, RMSE_Best, R2_Best, Regression_plot  = sparkregressionalgorithms.regressors(
                                                                algorithm_param = "DecisionTreeRegression", df = preprocessed_df,
                                                                parallelism_param = form.cleaned_data['parallelism'], n_folds_param = form.cleaned_data['nfolds'],
                                                                max_depth_param = form.cleaned_data['maxDepth'], max_bins_param = form.cleaned_data['maxBins'],
                                                                min_instances_per_node_param = form.cleaned_data['minInstancesPerNode'],
                                                                min_info_gain_param = form.cleaned_data['minInfoGain'],
                                                                max_memory_in_mb_param = form.cleaned_data['maxMemoryInMB'],
                                                                impurity_param = form.cleaned_data['impurity'], logger_param = logger)
                    
                    # Create result and store it in the database
                    result_instance = DecisionTreeRegressionResult.objects.create(parallelism = form.cleaned_data['parallelism'],
                                                                              numFolds = form.cleaned_data['nfolds'], dfSchema = df_schema, dfShape = df_shape, 
                                                                              dfShow = df_show, maxDepth = form.cleaned_data['maxDepth'], 
                                                                              maxBins = form.cleaned_data['maxBins'],
                                                                              minInstancesPerNode = form.cleaned_data['minInstancesPerNode'],
                                                                              minInfoGain = form.cleaned_data['minInfoGain'],
                                                                              maxMemoryInMB = form.cleaned_data['maxMemoryInMB'],
                                                                              impurity = form.cleaned_data['impurity'], RMSEMean = RMSE_Mean[0], MAEBest = MAE_Best,
                                                                              MAPEBest = MAPE_Best, MSEBest = MSE_Best, RMSEBest = RMSE_Best, R2Best = R2_Best,
                                                                              model = request.session['model'], RegressionPlot = Regression_plot, executionTime = str(time.time() - start_time))
                    
            elif (request.session['selected_algorithm'] == "RandomForestRegression"):
                
                # Get the regression algorithm's parameters
                form = RandomForestFormChar(request.POST)
                
                # check whether it's valid:
                if form.is_valid():
                    
                    # Run Algorithm
                    num_folds, RMSE_Mean, MAE_Best, MAPE_Best, MSE_Best, RMSE_Best, R2_Best, Regression_plot  = sparkregressionalgorithms.regressors(
                                                                algorithm_param = "RandomForestRegression", df = preprocessed_df,
                                                                parallelism_param = form.cleaned_data['parallelism'], n_folds_param = form.cleaned_data['nfolds'],
                                                                max_depth_param = form.cleaned_data['maxDepth'], max_bins_param = form.cleaned_data['maxBins'],
                                                                min_instances_per_node_param = form.cleaned_data['minInstancesPerNode'],
                                                                min_info_gain_param = form.cleaned_data['minInfoGain'],
                                                                max_memory_in_mb_param = form.cleaned_data['maxMemoryInMB'],
                                                                impurity_param = form.cleaned_data['impurity'],
                                                                subsamplingRate_param = form.cleaned_data['subsamplingRate'],
                                                                numTrees_param = form.cleaned_data['numTrees'],
                                                                featureSubsetStrategy_param = form.cleaned_data['featureSubsetStrategy'],
                                                                bootstrap_param = form.cleaned_data['bootstrap'], logger_param = logger)
                    
                    # Create result and store it in the database
                    result_instance = RandomForestRegressionResult.objects.create(parallelism = form.cleaned_data['parallelism'],
                                                                              numFolds = form.cleaned_data['nfolds'], dfSchema = df_schema, dfShape = df_shape, 
                                                                              dfShow = df_show, maxDepth = form.cleaned_data['maxDepth'], 
                                                                              maxBins = form.cleaned_data['maxBins'],
                                                                              minInstancesPerNode = form.cleaned_data['minInstancesPerNode'],
                                                                              minInfoGain = form.cleaned_data['minInfoGain'],
                                                                              maxMemoryInMB = form.cleaned_data['maxMemoryInMB'],
                                                                              impurity = form.cleaned_data['impurity'],
                                                                              subsamplingRate = form.cleaned_data['subsamplingRate'],
                                                                              numTrees = form.cleaned_data['numTrees'],
                                                                              featureSubsetStrategy = form.cleaned_data['featureSubsetStrategy'],
                                                                              bootstrap = form.cleaned_data['bootstrap'], RMSEMean = RMSE_Mean[0], MAEBest = MAE_Best,
                                                                              MAPEBest = MAPE_Best, MSEBest = MSE_Best, RMSEBest = RMSE_Best, R2Best = R2_Best,
                                                                              model = request.session['model'], RegressionPlot = Regression_plot, executionTime = str(time.time() - start_time))
                    
            elif (request.session['selected_algorithm'] == "GBTRegression"):
                
                # Get the regression algorithm's parameters
                form = GBTFormChar(request.POST)
                
                # check whether it's valid:
                if form.is_valid():
                    
                    # Run Algorithm
                    num_folds, RMSE_Mean, MAE_Best, MAPE_Best, MSE_Best, RMSE_Best, R2_Best, Regression_plot  = sparkregressionalgorithms.regressors(
                                                                algorithm_param = "GBTRegression", df = preprocessed_df,
                                                                parallelism_param = form.cleaned_data['parallelism'], n_folds_param = form.cleaned_data['nfolds'],
                                                                max_depth_param = form.cleaned_data['maxDepth'], max_bins_param = form.cleaned_data['maxBins'],
                                                                min_instances_per_node_param = form.cleaned_data['minInstancesPerNode'],
                                                                min_info_gain_param = form.cleaned_data['minInfoGain'],
                                                                max_memory_in_mb_param = form.cleaned_data['maxMemoryInMB'],
                                                                impurity_param = form.cleaned_data['impurity'],
                                                                subsamplingRate_param = form.cleaned_data['subsamplingRate'],
                                                                featureSubsetStrategy_param = form.cleaned_data['featureSubsetStrategy'],
                                                                maxIter_param = form.cleaned_data['maxIter'], 
                                                                lossType_param = form.cleaned_data['lossType'], validationTol_param = form.cleaned_data['validationTol'],
                                                                stepSize_param = form.cleaned_data['stepSize'], 
                                                                minWeightFractionPerNode_param = form.cleaned_data['minWeightFractionPerNode'], logger_param = logger)
                    
                    # Create result and store it in the database
                    result_instance = GBTRegressionResult.objects.create(parallelism = form.cleaned_data['parallelism'],
                                                                              numFolds = form.cleaned_data['nfolds'], dfSchema = df_schema, dfShape = df_shape, 
                                                                              dfShow = df_show, maxDepth = form.cleaned_data['maxDepth'], 
                                                                              maxBins = form.cleaned_data['maxBins'],
                                                                              minInstancesPerNode = form.cleaned_data['minInstancesPerNode'],
                                                                              minInfoGain = form.cleaned_data['minInfoGain'],
                                                                              maxMemoryInMB = form.cleaned_data['maxMemoryInMB'],
                                                                              impurity = form.cleaned_data['impurity'],
                                                                              subsamplingRate = form.cleaned_data['subsamplingRate'],
                                                                              featureSubsetStrategy = form.cleaned_data['featureSubsetStrategy'],
                                                                              maxIter = form.cleaned_data['maxIter'], 
                                                                              lossType = form.cleaned_data['lossType'], validationTol = form.cleaned_data['validationTol'],
                                                                              stepSize = form.cleaned_data['stepSize'], RMSEMean = RMSE_Mean[0], MAEBest = MAE_Best,
                                                                              MAPEBest = MAPE_Best, MSEBest = MSE_Best, RMSEBest = RMSE_Best, R2Best = R2_Best,
                                                                              model = request.session['model'], RegressionPlot = Regression_plot, executionTime = str(time.time() - start_time))
                    
            result_instance.save()
            
            spark.stop()

            return HttpResponseRedirect(reverse('bdmed:result_analysis', args=[request.session['selected_algorithm'], result_instance.Id]))
                    
    else:
            
        return HttpResponseRedirect(reverse("bdmed:problem_resolution"))
    
def ResultAnalysisView(request, algorithm_string, id_instance):
    
    template = loader.get_template('bdmed/algorithm_set_up.html')
    model = globals()[algorithm_string + "Result"]
    logger = logging.getLogger('app_api') 
    
    ri = model.objects.filter(Id=int(id_instance)).values()[0]
    
    if (algorithm_string == "BinaryLogisticRegression"):
    
        return render(request, "bdmed/result_analysis.html", {'selected_algorithm':algorithm_string, 'model':ri['model'], 'df_schema':ri['dfSchema'],
                                                                  'df_shape':ri['dfShape'],'num_folds':ri['numFolds'], 'AUC_mean':ri['AUCMean'], 'AUC_best':ri['AUCBest'],
                                                                  'accuracy_best':ri['AccuracyBest'], 'ROC_best':ri['numFolds'], 'PR_best':ri['numFolds'],
                                                                  'coeff_image':ri['CoeffImage'], 'ROC_image':ri['ROCImage'], 'PR_image':ri['PRImage'], 'maxIter':ri['maxIter'],
                                                                  'parallelism':ri['parallelism'], 'df_show':ri['dfShow'], 'dateOfCreation':ri['dateOfCreation'], "executionTime":ri['executionTime']})
    
    
    elif (algorithm_string == "MulticlassLogisticRegression"):
    
        return render(request, "bdmed/result_analysis.html", {'selected_algorithm':algorithm_string, 'model':ri['model'], 'df_schema':ri['dfSchema'],
                                                              'df_shape':ri['dfShape'],'num_folds':ri['numFolds'], 'maxIter':ri['maxIter'], 'parallelism':ri['parallelism'],
                                                              'F1Mean': ri['F1Mean'], 'coeffMatrix': ri['coeffMatrix'], 'accuracyBest': ri['accuracyBest'], 'F1ByLabel': ri['F1ByLabel'],
                                                              'FPRByLabel': ri['FPRByLabel'], 'TPRByLabel': ri['TPRByLabel'], 'precisionByLabel': ri['precisionByLabel'],
                                                              'recallByLabel': ri['recallByLabel'], 'F1Weighted': ri['F1Weighted'],  'FPRWeighted': ri['FPRWeighted'], 
                                                              'TPRWeighted': ri['TPRWeighted'], 'precisionWeighted': ri['precisionWeighted'], 'recallWeighted': ri['recallWeighted'],
                                                              'df_show':ri['dfShow'],'dateOfCreation':ri['dateOfCreation'], "executionTime":ri['executionTime']})
    
    elif (algorithm_string == "BinaryDecisionTree"):
    
        return render(request, 'bdmed/result_analysis.html', {'type':'Binary','selected_algorithm':algorithm_string, 'model':ri['model'], 'df_schema':ri['dfSchema'],
                                                              'df_shape':ri['dfShape'],"parallelism":ri['parallelism'],
                                                              "maxDepth":ri['maxDepth'], "maxBins":ri['maxBins'],
                                                              "minInstancesPerNode":ri['minInstancesPerNode'], "minInfoGain":ri['minInfoGain'],
                                                              "maxMemoryInMB":ri['maxMemoryInMB'], "impurity":ri['impurity'],"tv_map":ri['labelMapping'],
                                                              "num_folds":ri['numFolds'], "AUC_mean":ri['AUCMean'], "AUC_best":ri['AUCBest'], "accuracy":ri['AccuracyBest'],
                                                              "cm":ri['CMBest'], "cm_norm":ri['CMNormBest'],  "precision_0":ri['PrecisionBest_0'], "recall_0":ri['RecallBest_0'],
                                                              "FPR_0":ri['FPRBest_0'], "TNR_0":ri['TNRBest_0'], "F1_0":ri['F1Score_0'], "precision_1":ri['PrecisionBest_1'],
                                                              "recall_1":ri['RecallBest_1'], "FPR_1":ri['FPRBest_1'], "TNR_1":ri['TNRBest_1'], "F1_1":ri['F1Score_1'],
                                                              'ROC_image_0': ri['ROCImage_0'], 'ROC_image_1':ri['ROCImage_1'], 'df_show':ri['dfShow'],'dateOfCreation':ri['dateOfCreation'],
                                                              "executionTime":ri['executionTime'] })
    
    elif (algorithm_string == "MulticlassDecisionTree"):
        
        return render(request, 'bdmed/result_analysis.html', {'type':'Multiclass', 'selected_algorithm':algorithm_string, 'model':ri['model'], 'df_schema':ri['dfSchema'],
                                                              'df_shape':ri['dfShape'],"parallelism":ri['parallelism'],
                                                              "maxDepth":ri['maxDepth'], "maxBins":ri['maxBins'],
                                                              "minInstancesPerNode":ri['minInstancesPerNode'], "minInfoGain":ri['minInfoGain'],
                                                              "maxMemoryInMB":ri['maxMemoryInMB'], "impurity":ri['impurity'],"tv_map":ri['labelMapping'],
                                                              "num_folds":ri['numFolds'], 'accuracyBest': ri['accuracyBest'], 'F1ByLabel': ri['F1ByLabel'],
                                                              'FPRByLabel': ri['FPRByLabel'], 'TNRByLabel': ri['TNRByLabel'], 'precisionByLabel': ri['precisionByLabel'],
                                                              'recallByLabel': ri['recallByLabel'], 'F1Weighted': ri['F1Weighted'],  'FPRWeighted': ri['FPRWeighted'], 
                                                              'TNRWeighted': ri['TNRWeighted'], 'precisionWeighted': ri['precisionWeighted'], 'recallWeighted': ri['recallWeighted'],
                                                              'df_show':ri['dfShow'],'dateOfCreation':ri['dateOfCreation'], "cm":ri['CMBest'], "cm_norm":ri['CMNormBest'], "executionTime":ri['executionTime']})
    
    elif (algorithm_string == "BinaryRandomForest"):
    
        return render(request, 'bdmed/result_analysis.html', {'type':'Binary', 'selected_algorithm':algorithm_string, 'model':ri['model'], 'df_schema':ri['dfSchema'],
                                                              'df_shape':ri['dfShape'],"parallelism":ri['parallelism'],
                                                              "maxDepth":ri['maxDepth'], "maxBins":ri['maxBins'],
                                                              "minInstancesPerNode":ri['minInstancesPerNode'], "minInfoGain":ri['minInfoGain'],
                                                              "maxMemoryInMB":ri['maxMemoryInMB'], "impurity":ri['impurity'],"tv_map":ri['labelMapping'],
                                                              "subsamplingRate":ri["subsamplingRate"], "featureSubsetStrategy":ri["featureSubsetStrategy"],
                                                              "numTrees": ri["numTrees"], "bootstrap":ri["bootstrap"],
                                                              "num_folds":ri['numFolds'], "AUC_mean":ri['AUCMean'], "AUC_best":ri['AUCBest'], "accuracy":ri['AccuracyBest'],
                                                              "cm":ri['CMBest'], "cm_norm":ri['CMNormBest'],  "precision_0":ri['PrecisionBest_0'], "recall_0":ri['RecallBest_0'],
                                                              "FPR_0":ri['FPRBest_0'], "TNR_0":ri['TNRBest_0'], "F1_0":ri['F1Score_0'], "precision_1":ri['PrecisionBest_1'],
                                                              "recall_1":ri['RecallBest_1'], "FPR_1":ri['FPRBest_1'], "TNR_1":ri['TNRBest_1'], "F1_1":ri['F1Score_1'],
                                                              'ROC_image_0': ri['ROCImage_0'], 'ROC_image_1':ri['ROCImage_1'], 'df_show':ri['dfShow'],'dateOfCreation':ri['dateOfCreation'], "executionTime":ri['executionTime']})
    
    elif (algorithm_string == "MulticlassRandomForest"):
        
        return render(request, 'bdmed/result_analysis.html', {'type':'Multiclass', 'selected_algorithm':algorithm_string, 'model':ri['model'], 'df_schema':ri['dfSchema'],
                                                              'df_shape':ri['dfShape'],"parallelism":ri['parallelism'],
                                                              "maxDepth":ri['maxDepth'], "maxBins":ri['maxBins'],
                                                              "minInstancesPerNode":ri['minInstancesPerNode'], "minInfoGain":ri['minInfoGain'],
                                                              "maxMemoryInMB":ri['maxMemoryInMB'], "impurity":ri['impurity'],"tv_map":ri['labelMapping'],
                                                              "subsamplingRate":ri["subsamplingRate"], "featureSubsetStrategy":ri["featureSubsetStrategy"],
                                                              "numTrees": ri["numTrees"], "bootstrap":ri["bootstrap"],
                                                              "num_folds":ri['numFolds'], 'accuracyBest': ri['accuracyBest'], 'F1ByLabel': ri['F1ByLabel'],
                                                              'FPRByLabel': ri['FPRByLabel'], 'TNRByLabel': ri['TNRByLabel'], 'precisionByLabel': ri['precisionByLabel'],
                                                              'recallByLabel': ri['recallByLabel'], 'F1Weighted': ri['F1Weighted'],  'FPRWeighted': ri['FPRWeighted'], 
                                                              'TNRWeighted': ri['TNRWeighted'], 'precisionWeighted': ri['precisionWeighted'], 'recallWeighted': ri['recallWeighted'],
                                                              'df_show':ri['dfShow'],'dateOfCreation':ri['dateOfCreation'], "cm":ri['CMBest'], "cm_norm":ri['CMNormBest'], "executionTime":ri['executionTime']})
    
    elif (algorithm_string == "BinaryGBT"):
        
        return render(request, 'bdmed/result_analysis.html', {'type':'Binary', 'selected_algorithm':algorithm_string, 'model':ri['model'], 'df_schema':ri['dfSchema'],
                                                              'df_shape':ri['dfShape'],"parallelism":ri['parallelism'],
                                                              "maxDepth":ri['maxDepth'], "maxBins":ri['maxBins'],
                                                              "minInstancesPerNode":ri['minInstancesPerNode'], "minInfoGain":ri['minInfoGain'],
                                                              "maxMemoryInMB":ri['maxMemoryInMB'], "impurity":ri['impurity'],"tv_map":ri['labelMapping'],
                                                              "subsamplingRate":ri["subsamplingRate"], "featureSubsetStrategy":ri["featureSubsetStrategy"],
                                                              "maxIter":ri['maxIter'], "lossType":ri['lossType'], "validationTol":ri['validationTol'],
                                                              "stepSize":ri['stepSize'], "minWeightFractionPerNode":ri['minWeightFractionPerNode'],
                                                              "num_folds":ri['numFolds'], "AUC_mean":ri['AUCMean'], "AUC_best":ri['AUCBest'], "accuracy":ri['AccuracyBest'],
                                                              "cm":ri['CMBest'], "cm_norm":ri['CMNormBest'],  "precision_0":ri['PrecisionBest_0'], "recall_0":ri['RecallBest_0'],
                                                              "FPR_0":ri['FPRBest_0'], "TNR_0":ri['TNRBest_0'], "F1_0":ri['F1Score_0'], "precision_1":ri['PrecisionBest_1'],
                                                              "recall_1":ri['RecallBest_1'], "FPR_1":ri['FPRBest_1'], "TNR_1":ri['TNRBest_1'], "F1_1":ri['F1Score_1'],
                                                              'df_show':ri['dfShow'],'dateOfCreation':ri['dateOfCreation'], "executionTime":ri['executionTime']})
    
    elif (algorithm_string == "BinaryNaiveBayes"):
    
        return render(request, 'bdmed/result_analysis.html', {'type':'Binary', 'selected_algorithm':algorithm_string, 'model':ri['model'], 'df_schema':ri['dfSchema'],
                                                              'df_shape':ri['dfShape'],"parallelism":ri['parallelism'], "smoothing":ri['smoothing'], "modelType":ri['modelType'],
                                                              "num_folds":ri['numFolds'], "AUC_mean":ri['AUCMean'], "AUC_best":ri['AUCBest'], "accuracy":ri['AccuracyBest'],
                                                              "cm":ri['CMBest'], "cm_norm":ri['CMNormBest'],  "precision_0":ri['PrecisionBest_0'], "recall_0":ri['RecallBest_0'],
                                                              "FPR_0":ri['FPRBest_0'], "TNR_0":ri['TNRBest_0'], "F1_0":ri['F1Score_0'], "precision_1":ri['PrecisionBest_1'],
                                                              "recall_1":ri['RecallBest_1'], "FPR_1":ri['FPRBest_1'], "TNR_1":ri['TNRBest_1'], "F1_1":ri['F1Score_1'],
                                                              'ROC_image_0': ri['ROCImage_0'], 'ROC_image_1':ri['ROCImage_1'], 'df_show':ri['dfShow'],'dateOfCreation':ri['dateOfCreation'], "executionTime":ri['executionTime']})
    
    elif (algorithm_string == "MulticlassNaiveBayes"):
        
        return render(request, 'bdmed/result_analysis.html', {'type':'Multiclass', 'selected_algorithm':algorithm_string, 'model':ri['model'], 'df_schema':ri['dfSchema'],
                                                              'df_shape':ri['dfShape'],"parallelism":ri['parallelism'], "smoothing":ri['smoothing'], "modelType":ri['modelType'],
                                                              "num_folds":ri['numFolds'], 'accuracyBest': ri['accuracyBest'], 'F1ByLabel': ri['F1ByLabel'],
                                                              'FPRByLabel': ri['FPRByLabel'], 'TNRByLabel': ri['TNRByLabel'], 'precisionByLabel': ri['precisionByLabel'],
                                                              'recallByLabel': ri['recallByLabel'], 'F1Weighted': ri['F1Weighted'],  'FPRWeighted': ri['FPRWeighted'], 
                                                              'TNRWeighted': ri['TNRWeighted'], 'precisionWeighted': ri['precisionWeighted'], 'recallWeighted': ri['recallWeighted'],
                                                              'df_show':ri['dfShow'],'dateOfCreation':ri['dateOfCreation'], "cm":ri['CMBest'], "cm_norm":ri['CMNormBest'], "executionTime":ri['executionTime']})
    
    elif (algorithm_string == "BinaryLinearSVC"):
    
        return render(request, 'bdmed/result_analysis.html', {'type':'Binary', 'selected_algorithm':algorithm_string, 'model':ri['model'], 'df_schema':ri['dfSchema'],
                                                              'df_shape':ri['dfShape'],"parallelism":ri['parallelism'], "aggregationDepth":ri['aggregationDepth'], "maxIter":ri['maxIter'],
                                                              "regParam":ri['regParam'], "standardization":ri['standardization'], "tol":ri['tol'],
                                                              "num_folds":ri['numFolds'], "AUC_mean":ri['AUCMean'], "AUC_best":ri['AUCBest'], "accuracy":ri['AccuracyBest'],
                                                              "cm":ri['CMBest'], "cm_norm":ri['CMNormBest'],  "precision_0":ri['PrecisionBest_0'], "recall_0":ri['RecallBest_0'],
                                                              "FPR_0":ri['FPRBest_0'], "TNR_0":ri['TNRBest_0'], "F1_0":ri['F1Score_0'], "precision_1":ri['PrecisionBest_1'],
                                                              "recall_1":ri['RecallBest_1'], "FPR_1":ri['FPRBest_1'], "TNR_1":ri['TNRBest_1'], "F1_1":ri['F1Score_1'],
                                                              'df_show':ri['dfShow'],'dateOfCreation':ri['dateOfCreation'], "executionTime":ri['executionTime']})
    
    elif (algorithm_string == "DecisionTreeRegression"):
        
        return render(request, 'bdmed/result_analysis.html', {'type':'Regression','selected_algorithm':algorithm_string, 'model':ri['model'], 'df_schema':ri['dfSchema'],
                                                              'df_shape':ri['dfShape'], 'df_show':ri["dfShow"], "parallelism":ri['parallelism'],
                                                              "maxDepth":ri['maxDepth'], "maxBins":ri['maxBins'], 'dateOfCreation':ri['dateOfCreation'],
                                                              "minInstancesPerNode":ri['minInstancesPerNode'], "minInfoGain":ri['minInfoGain'],
                                                              "maxMemoryInMB":ri['maxMemoryInMB'], "impurity":ri['impurity'],
                                                              "num_folds":ri['numFolds'], "RMSEMean":ri['RMSEMean'], "MAEBest":ri['MAEBest'], "MAPEBest":ri['MAPEBest'],
                                                              "MSEBest":ri['MSEBest'], "RMSEBest":ri['RMSEBest'],  "R2Best":ri['R2Best'],
                                                              "RegressionPlot":ri["RegressionPlot"], "executionTime":ri['executionTime']})
    
    elif (algorithm_string == "RandomForestRegression"):
        
        return render(request, 'bdmed/result_analysis.html', {'type':'Regression', 'selected_algorithm':algorithm_string, 'model':ri['model'], 'df_schema':ri['dfSchema'],
                                                              'df_shape':ri['dfShape'],"parallelism":ri['parallelism'], 'df_show':ri['dfShow'],
                                                              'dateOfCreation':ri['dateOfCreation'],
                                                              "maxDepth":ri['maxDepth'], "maxBins":ri['maxBins'],
                                                              "minInstancesPerNode":ri['minInstancesPerNode'], "minInfoGain":ri['minInfoGain'],
                                                              "maxMemoryInMB":ri['maxMemoryInMB'], "impurity":ri['impurity'],
                                                              "subsamplingRate":ri["subsamplingRate"], "featureSubsetStrategy":ri["featureSubsetStrategy"],
                                                              "numTrees": ri["numTrees"], "bootstrap":ri["bootstrap"],
                                                              "num_folds":ri['numFolds'], "RMSEMean":ri['RMSEMean'], "MAEBest":ri['MAEBest'], "MAPEBest":ri['MAPEBest'],
                                                              "MSEBest":ri['MSEBest'], "RMSEBest":ri['RMSEBest'],  "R2Best":ri['R2Best'], 
                                                              "RegressionPlot":ri["RegressionPlot"], "executionTime":ri['executionTime']})
    
    elif (algorithm_string == "GBTRegression"):
        
        return render(request, 'bdmed/result_analysis.html', {'type':'Regression', 'selected_algorithm':algorithm_string, 'model':ri['model'], 'df_schema':ri['dfSchema'],
                                                              'df_shape':ri['dfShape'],"parallelism":ri['parallelism'], 'df_show':ri['dfShow'],
                                                              'dateOfCreation':ri['dateOfCreation'],
                                                              "maxDepth":ri['maxDepth'], "maxBins":ri['maxBins'],
                                                              "minInstancesPerNode":ri['minInstancesPerNode'], "minInfoGain":ri['minInfoGain'],
                                                              "maxMemoryInMB":ri['maxMemoryInMB'], "impurity":ri['impurity'],
                                                              "subsamplingRate":ri["subsamplingRate"], "featureSubsetStrategy":ri["featureSubsetStrategy"],
                                                              "maxIter":ri['maxIter'], "lossType":ri['lossType'], "validationTol":ri['validationTol'],
                                                              "stepSize":ri['stepSize'], "minWeightFractionPerNode":ri['minWeightFractionPerNode'],
                                                              "num_folds":ri['numFolds'], "RMSEMean":ri['RMSEMean'], "MAEBest":ri['MAEBest'], "MAPEBest":ri['MAPEBest'],
                                                              "MSEBest":ri['MSEBest'], "RMSEBest":ri['RMSEBest'],  "R2Best":ri['R2Best'],
                                                              "RegressionPlot":ri["RegressionPlot"], "executionTime":ri['executionTime']})
    
def PreviousResultsView(request):
    template = loader.get_template('bdmed/previous_results.html')
    
    # set up all the registered results models
    models_string = ["BinaryLogisticRegression", "MulticlassLogisticRegression", "BinaryDecisionTree", 'MulticlassDecisionTree', "BinaryRandomForest", "MulticlassRandomForest", "BinaryGBT",
                     "BinaryNaiveBayes", "MulticlassNaiveBayes", "BinaryLinearSVC", "DecisionTreeRegression", 'RandomForestRegression', 'GBTRegression']
    models_main_measures = ["AUCMean", "F1Mean", "AUCMean", "F1Mean", "AUCMean", "F1Mean", "AUCMean", "AUCMean", "F1Mean", "AUCMean", "RMSEMean", "RMSEMean", "RMSEMean"]
    
    # set up return lists
    populated_models = []
    model_instances = []
    
    # logger set up
    logger = logging.getLogger('app_api')
    
    for model_string, measure in zip(models_string, models_main_measures):
        
        model_instances_local = []
        
        # get the model variable
        model = globals()[model_string + "Result"]
        
        # get the instances of results (order by date, newest first)
        results = model.objects.order_by('-dateOfCreation').values_list("Id", "dateOfCreation", measure)
        
        # if there is any instance of the model result, append it to the return list
        if (len(results) > 0):
            
            # make a list of Id, Date of creation and Measure for each result
            for elem in results:
                IDM_list = []
                IDM_list.append(int(elem[0])) # Id
                IDM_list.append(str(elem[1])[0:19]) # DateofCreation
                IDM_list.append(float(elem[2])) # Measure
                model_instances_local.append(IDM_list)
            
            # get the final model and instances list
            populated_models.append(model_string)
            model_instances.append(model_instances_local)
            
    return render (request, "bdmed/previous_results.html", {'populated_models_instances': zip(populated_models,model_instances,models_main_measures)})

# view that for cluster set up (distributed execution of algorithms)
def ClusterSetUpView(request):

    if ("GET" == request.method):
        
        form = ClusterSetUpForm()
        
        return render(request, "bdmed/cluster_set_up.html", {'form': form})
    
    # if not get, then POST 
    else:
       
        # create a form instance and populate it with data from the request:
        form = ClusterSetUpForm(request.POST)
        # check whether it's valid:
        if form.is_valid():
            
            # set up all the cluster execution parameters 
            request.session['Distributed'] = form.cleaned_data['Distributed']
            request.session['ConexionToSparkMaster'] = form.cleaned_data['ConexionToSparkMaster']
            request.session['NumberOfCores'] = form.cleaned_data['NumberOfCores']
            request.session['NumberOfCoresPerExecutor'] = form.cleaned_data['NumberOfCoresPerExecutor']
            request.session['ExecutorMemory'] = form.cleaned_data['ExecutorMemory']

            return HttpResponseRedirect(reverse("bdmed:algorithm_set_up"))

# Test and debug view
def TestView(request):

    model = globals()[request.session['model']]
    
    my_keyword = 'Id__gte'
    my_filter_value = 10
    
    my_filter = {}
    my_filter[my_keyword] = my_filter_value

    my_object = model.objects.filter(**my_filter)
    
    return render(request, 'bdmed/test.html', {'my_object': my_object})