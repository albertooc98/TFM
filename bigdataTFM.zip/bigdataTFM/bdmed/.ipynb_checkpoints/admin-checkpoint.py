from django.contrib import admin

from .models import *

# Models of datasets
admin.site.register(CMBD)
admin.site.register(Bank)
admin.site.register(Iris)
admin.site.register(AcuteInflammations)
admin.site.register(MedicalCost)
admin.site.register(ContraceptiveMethod)

# Models of results of algorithms
admin.site.register(BinaryLogisticRegressionResult)
admin.site.register(MulticlassLogisticRegressionResult)
admin.site.register(BinaryDecisionTreeResult)
admin.site.register(MulticlassDecisionTreeResult)
admin.site.register(BinaryRandomForestResult)
admin.site.register(MulticlassRandomForestResult)
admin.site.register(BinaryGBTResult)
admin.site.register(BinaryNaiveBayesResult)
admin.site.register(MulticlassNaiveBayesResult)
admin.site.register(BinaryLinearSVCResult)
admin.site.register(DecisionTreeRegressionResult)
admin.site.register(RandomForestRegressionResult)
admin.site.register(GBTRegressionResult)