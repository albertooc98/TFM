from django.db import models
from django.utils.timezone import now

class CMBD(models.Model):
    Id = models.AutoField(primary_key=True)
    HISTORIAmodificada = models.CharField(max_length=200, default=None, blank=True, null=True)
    TXTFECNAC = models.CharField(max_length=200, default=None, blank=True, null=True)
    SEXO = models.CharField(max_length=200, default=None, blank=True, null=True)
    PROCEDE = models.CharField(max_length=200, default=None, blank=True, null=True)
    TXTFECCONT = models.CharField(max_length=200, default=None, blank=True, null=True)
    TXTFECING = models.CharField(max_length=200, default=None, blank=True, null=True)
    TIPING = models.CharField(max_length=200, default=None, blank=True, null=True)
    TXTFECALT = models.CharField(max_length=200, default=None, blank=True, null=True)
    TIPALT = models.CharField(max_length=200, default=None, blank=True, null=True)
    CONTINUIDA = models.CharField(max_length=200, default=None, blank=True, null=True)
    TRASH = models.CharField(max_length=200, default=None, blank=True, null=True)
    MUNIRESI = models.CharField(max_length=200, default=None, blank=True, null=True)
    PAISNAC = models.CharField(max_length=200, default=None, blank=True, null=True)
    REGFIN = models.CharField(max_length=200, default=None, blank=True, null=True)
    UCI = models.CharField(max_length=200, default=None, blank=True, null=True)
    DIASUCI = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    EDAD = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    TIEMPOING = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    MES = models.CharField(max_length=200, default=None, blank=True, null=True)
    MESNUM = models.CharField(max_length=200, default=None, blank=True, null=True)
    ESTACION = models.CharField(max_length=200, default=None, blank=True, null=True)
    C1 = models.CharField(max_length=200, default=None, blank=True, null=True)
    ANO = models.CharField(max_length=200, default=None, blank=True, null=True)
    
    def __str__(self):
        return self.HISTORIAmodificada
    
class Bank(models.Model):
    Id = models.AutoField(primary_key=True)
    age = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    job = models.CharField(max_length=200, default=None, blank=True, null=True)
    marital = models.CharField(max_length=200, default=None, blank=True, null=True)
    education = models.CharField(max_length=200, default=None, blank=True, null=True)
    default = models.CharField(max_length=200, default=None, blank=True, null=True)
    balance = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    housing = models.CharField(max_length=200, default=None, blank=True, null=True)
    loan = models.CharField(max_length=200, default=None, blank=True, null=True)
    contact = models.CharField(max_length=200, default=None, blank=True, null=True)
    day = models.CharField(max_length=200, default=None, blank=True, null=True)
    month = models.CharField(max_length=200, default=None, blank=True, null=True)
    duration = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    campaign = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    pdays = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    previous = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    poutcome = models.CharField(max_length=200, default=None, blank=True, null=True)
    deposit = models.CharField(max_length=200, default=None, blank=True, null=True)
    
    def __str__(self):
        return str(self.Id)
    
class Iris(models.Model):
    Id = models.AutoField(primary_key=True)
    sepalLength = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    sepalWidth = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    petalLength = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    petalWidth = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    variety = models.CharField(max_length=200, default=None, blank=True, null=True)
    
    def __str__(self):
        return str(self.Id)
    
class AcuteInflammations(models.Model):
    Id = models.AutoField(primary_key=True)
    TemperatureOfPatient = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    OccurrenceOfNausea = models.CharField(max_length=200, default=None, blank=True, null=True)
    LumbarPain = models.CharField(max_length=200, default=None, blank=True, null=True)
    UrinePushing = models.CharField(max_length=200, default=None, blank=True, null=True)
    MicturitionPains = models.CharField(max_length=200, default=None, blank=True, null=True)
    BurningOfUrethra = models.CharField(max_length=200, default=None, blank=True, null=True)
    InflammationOfUrinaryBladder = models.CharField(max_length=200, default=None, blank=True, null=True)
    NephritisOfRenalPelvisOrigin = models.CharField(max_length=200, default=None, blank=True, null=True)
    
    def __str__(self):
        return str(self.Id)
    
class MedicalCost(models.Model):
    Id = models.AutoField(primary_key=True)
    Age = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    Sex = models.CharField(max_length=200, default=None, blank=True, null=True)
    Bmi = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    Children = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    Smoker = models.CharField(max_length=200, default=None, blank=True, null=True)
    Region = models.CharField(max_length=200, default=None, blank=True, null=True)
    Charges = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    
    def __str__(self):
        return str(self.Id)
    
class ContraceptiveMethod(models.Model):
    Id = models.AutoField(primary_key=True)
    WifeAge = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    WifeEducation = models.CharField(max_length=200, default=None, blank=True, null=True)
    HusbandEducation = models.CharField(max_length=200, default=None, blank=True, null=True)
    NumberBorn = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    WifeReligion = models.CharField(max_length=200, default=None, blank=True, null=True)
    WifeWorking = models.CharField(max_length=200, default=None, blank=True, null=True)
    HusbandOccupation = models.CharField(max_length=200, default=None, blank=True, null=True)
    StandardOfLivingIndex = models.CharField(max_length=200, default=None, blank=True, null=True)
    MediaExposure = models.CharField(max_length=200, default=None, blank=True, null=True)
    ContraceptiveMethod = models.CharField(max_length=200, default=None, blank=True, null=True)
    
    def __str__(self):
        return str(self.Id)
    
class BinaryLogisticRegressionResult(models.Model):
    
    # Automatic Id
    Id = models.AutoField(primary_key=True)
    
    # Automatic Datetime - It will be set to the time the instance is first created
    dateOfCreation = models.DateTimeField(default=now, editable=False)
    
    # name of the model
    model = models.CharField(max_length=1000, default=None, blank=True, null=True)
    
    # Execution time
    executionTime = models.CharField(max_length=1000, default=None, blank=True, null=True)
    
    # Algorithm Parameters
    maxIter = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    parallelism = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    numFolds = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    
    # Dataframe Schema
    dfSchema = models.CharField(max_length=20000, default=None, blank=True, null=True)
    dfShow = models.CharField(max_length=40000, default=None, blank=True, null=True)
    dfShape = models.CharField(max_length=200, default=None, blank=True, null=True)
    
    # Algorithm Results
    AUCMean = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    AUCBest = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    AccuracyBest = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    CoeffImage = models.CharField(max_length=100000, default=None, blank=True, null=True)
    ROCImage = models.CharField(max_length=100000, default=None, blank=True, null=True)
    PRImage = models.CharField(max_length=100000, default=None, blank=True, null=True)
    
class BinaryDecisionTreeResult(models.Model):
    
    # Automatic Id
    Id = models.AutoField(primary_key=True)
    
    # Automatic Datetime - It will be set to the time the instance is first created
    dateOfCreation = models.DateTimeField(default=now, editable=False)
    
    # name of the model
    model = models.CharField(max_length=1000, default=None, blank=True, null=True)
    
    # Execution time
    executionTime = models.CharField(max_length=1000, default=None, blank=True, null=True)
    
    # Algorithm Parameters
    maxDepth = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    maxBins = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    minInstancesPerNode = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    minInfoGain = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    maxMemoryInMB = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    impurity = models.CharField(max_length=200, default=None, blank=True, null=True)
    
    parallelism = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    numFolds = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    
    # Dataframe Schema
    dfSchema = models.CharField(max_length=20000, default=None, blank=True, null=True)
    dfShow = models.CharField(max_length=40000, default=None, blank=True, null=True)
    dfShape = models.CharField(max_length=200, default=None, blank=True, null=True)
    
    # Algorithm Results
    labelMapping = models.CharField(max_length=1000, default=None, blank=True, null=True)
    AUCMean = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    AUCBest = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    AccuracyBest = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    CMBest = models.CharField(max_length=100000, default=None, blank=True, null=True)
    CMNormBest = models.CharField(max_length=100000, default=None, blank=True, null=True)
    PrecisionBest_0 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    RecallBest_0 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    FPRBest_0 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    TNRBest_0 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    F1Score_0 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    ROCImage_0 = models.CharField(max_length=100000, default=None, blank=True, null=True)
    PrecisionBest_1 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    RecallBest_1 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    FPRBest_1 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    TNRBest_1 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    F1Score_1 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    ROCImage_1 = models.CharField(max_length=100000, default=None, blank=True, null=True)
    
class BinaryRandomForestResult(models.Model):
    
    # Automatic Id
    Id = models.AutoField(primary_key=True)
    
    # Automatic Datetime - It will be set to the time the instance is first created
    dateOfCreation = models.DateTimeField(default=now, editable=False)
    
    # name of the model
    model = models.CharField(max_length=1000, default=None, blank=True, null=True)
    
    # Execution time
    executionTime = models.CharField(max_length=1000, default=None, blank=True, null=True)
    
    # Algorithm Parameters
    maxDepth = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    maxBins = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    minInstancesPerNode = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    minInfoGain = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    maxMemoryInMB = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    impurity = models.CharField(max_length=200, default=None, blank=True, null=True)
    subsamplingRate = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    featureSubsetStrategy = models.CharField(max_length=200, default=None, blank=True, null=True)
    numTrees = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    bootstrap = models.BooleanField(default=None, blank=True, null=True)
    
    parallelism = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    numFolds = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    
    # Dataframe Schema
    dfSchema = models.CharField(max_length=20000, default=None, blank=True, null=True)
    dfShow = models.CharField(max_length=40000, default=None, blank=True, null=True)
    dfShape = models.CharField(max_length=200, default=None, blank=True, null=True)
    
    # Algorithm Results
    labelMapping = models.CharField(max_length=1000, default=None, blank=True, null=True)
    AUCMean = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    AUCBest = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    AccuracyBest = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    CMBest = models.CharField(max_length=100000, default=None, blank=True, null=True)
    CMNormBest = models.CharField(max_length=100000, default=None, blank=True, null=True)
    PrecisionBest_0 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    RecallBest_0 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    FPRBest_0 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    TNRBest_0 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    F1Score_0 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    ROCImage_0 = models.CharField(max_length=100000, default=None, blank=True, null=True)
    PrecisionBest_1 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    RecallBest_1 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    FPRBest_1 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    TNRBest_1 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    F1Score_1 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    ROCImage_1 = models.CharField(max_length=100000, default=None, blank=True, null=True)
    
class BinaryGBTResult(models.Model):
    # Automatic Id
    Id = models.AutoField(primary_key=True)
    
    # Automatic Datetime - It will be set to the time the instance is first created
    dateOfCreation = models.DateTimeField(default=now, editable=False)
    
    # name of the model
    model = models.CharField(max_length=1000, default=None, blank=True, null=True)
    
    # Execution time
    executionTime = models.CharField(max_length=1000, default=None, blank=True, null=True)
    
    # Algorithm Parameters
    maxDepth = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    maxBins = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    minInstancesPerNode = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    minInfoGain = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    maxMemoryInMB = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    impurity = models.CharField(max_length=200, default=None, blank=True, null=True)
    subsamplingRate = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    featureSubsetStrategy = models.CharField(max_length=200, default=None, blank=True, null=True)
    maxIter = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    lossType = models.CharField(max_length=200, default=None, blank=True, null=True)
    validationTol = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    stepSize = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    minWeightFractionPerNode = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    
    parallelism = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    numFolds = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    
    # Dataframe Schema
    dfSchema = models.CharField(max_length=20000, default=None, blank=True, null=True)
    dfShow = models.CharField(max_length=40000, default=None, blank=True, null=True)
    dfShape = models.CharField(max_length=200, default=None, blank=True, null=True)
    
    # Algorithm Results
    labelMapping = models.CharField(max_length=1000, default=None, blank=True, null=True)
    AUCMean = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    AUCBest = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    AccuracyBest = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    CMBest = models.CharField(max_length=100000, default=None, blank=True, null=True)
    CMNormBest = models.CharField(max_length=100000, default=None, blank=True, null=True)
    PrecisionBest_0 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    RecallBest_0 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    FPRBest_0 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    TNRBest_0 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    F1Score_0 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    PrecisionBest_1 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    RecallBest_1 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    FPRBest_1 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    TNRBest_1 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    F1Score_1 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    
class BinaryNaiveBayesResult(models.Model):
    # Automatic Id
    Id = models.AutoField(primary_key=True)
    
    # Automatic Datetime - It will be set to the time the instance is first created
    dateOfCreation = models.DateTimeField(default=now, editable=False)
    
    # name of the model
    model = models.CharField(max_length=1000, default=None, blank=True, null=True)
    
    # Execution time
    executionTime = models.CharField(max_length=1000, default=None, blank=True, null=True)
    
    # Algorithm Parameters
    smoothing = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    modelType = models.CharField(max_length=200, default=None, blank=True, null=True)
    
    parallelism = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    numFolds = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    
    # Dataframe Schema
    dfSchema = models.CharField(max_length=20000, default=None, blank=True, null=True)
    dfShow = models.CharField(max_length=40000, default=None, blank=True, null=True)
    dfShape = models.CharField(max_length=200, default=None, blank=True, null=True)
    
    # Algorithm Results
    labelMapping = models.CharField(max_length=1000, default=None, blank=True, null=True)
    AUCMean = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    AUCBest = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    AccuracyBest = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    CMBest = models.CharField(max_length=100000, default=None, blank=True, null=True)
    CMNormBest = models.CharField(max_length=100000, default=None, blank=True, null=True)
    PrecisionBest_0 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    RecallBest_0 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    FPRBest_0 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    TNRBest_0 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    F1Score_0 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    ROCImage_0 = models.CharField(max_length=100000, default=None, blank=True, null=True)
    PrecisionBest_1 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    RecallBest_1 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    FPRBest_1 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    TNRBest_1 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    F1Score_1 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    ROCImage_1 = models.CharField(max_length=100000, default=None, blank=True, null=True)
    
class BinaryLinearSVCResult(models.Model):
    
    # Automatic Id
    Id = models.AutoField(primary_key=True)
    
    # Automatic Datetime - It will be set to the time the instance is first created
    dateOfCreation = models.DateTimeField(default=now, editable=False)
    
    # name of the model
    model = models.CharField(max_length=1000, default=None, blank=True, null=True)
    
    # Execution time
    executionTime = models.CharField(max_length=1000, default=None, blank=True, null=True)
    
    # Algorithm Parameters
    aggregationDepth = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    maxIter = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    regParam = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    standardization = models.BooleanField(default=None, blank=True, null=True)
    tol = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    
    parallelism = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    numFolds = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    
    # Dataframe Schema
    dfSchema = models.CharField(max_length=20000, default=None, blank=True, null=True)
    dfShow = models.CharField(max_length=40000, default=None, blank=True, null=True)
    dfShape = models.CharField(max_length=200, default=None, blank=True, null=True)
    
    # Algorithm Results
    labelMapping = models.CharField(max_length=1000, default=None, blank=True, null=True)
    AUCMean = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    AUCBest = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    AccuracyBest = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    CMBest = models.CharField(max_length=100000, default=None, blank=True, null=True)
    CMNormBest = models.CharField(max_length=100000, default=None, blank=True, null=True)
    PrecisionBest_0 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    RecallBest_0 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    FPRBest_0 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    TNRBest_0 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    F1Score_0 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    PrecisionBest_1 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    RecallBest_1 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    FPRBest_1 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    TNRBest_1 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    F1Score_1 = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)

class MulticlassLogisticRegressionResult(models.Model):
    
    # Automatic Id    
    Id = models.AutoField(primary_key=True)
    
    # Automatic Datetime - It will be set to the time the instance is first created
    dateOfCreation = models.DateTimeField(default=now, editable=False)
    
    # name of the model
    model = models.CharField(max_length=1000, default=None, blank=True, null=True)
    
    # Execution time
    executionTime = models.CharField(max_length=1000, default=None, blank=True, null=True)
    
    # Algorithm Parameters
    maxIter = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    parallelism = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    numFolds = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    
    # Dataframe Schema
    dfSchema = models.CharField(max_length=20000, default=None, blank=True, null=True)
    dfShow = models.CharField(max_length=40000, default=None, blank=True, null=True)
    dfShape = models.CharField(max_length=200, default=None, blank=True, null=True)
    
    # Algorithm Results
    F1Mean = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    coeffMatrix = models.CharField(max_length=20000, default=None, blank=True, null=True)
    accuracyBest = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    F1ByLabel = models.CharField(max_length=20000, default=None, blank=True, null=True)
    FPRByLabel = models.CharField(max_length=20000, default=None, blank=True, null=True)
    TPRByLabel = models.CharField(max_length=20000, default=None, blank=True, null=True)
    precisionByLabel = models.CharField(max_length=20000, default=None, blank=True, null=True)
    recallByLabel = models.CharField(max_length=20000, default=None, blank=True, null=True)
    F1Weighted = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    FPRWeighted = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    TPRWeighted = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    precisionWeighted = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    recallWeighted = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    
class MulticlassDecisionTreeResult(models.Model):
    
    # Automatic Id    
    Id = models.AutoField(primary_key=True)
    
    # Automatic Datetime - It will be set to the time the instance is first created
    dateOfCreation = models.DateTimeField(default=now, editable=False)
    
    # name of the model
    model = models.CharField(max_length=1000, default=None, blank=True, null=True)
    
    # Execution time
    executionTime = models.CharField(max_length=1000, default=None, blank=True, null=True)
    
    # Algorithm Parameters
    maxDepth = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    maxBins = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    minInstancesPerNode = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    minInfoGain = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    maxMemoryInMB = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    impurity = models.CharField(max_length=200, default=None, blank=True, null=True)
    
    parallelism = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    numFolds = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    
    # Dataframe Schema
    dfSchema = models.CharField(max_length=20000, default=None, blank=True, null=True)
    dfShow = models.CharField(max_length=40000, default=None, blank=True, null=True)
    dfShape = models.CharField(max_length=200, default=None, blank=True, null=True)
    
    # Algorithm Results
    labelMapping = models.CharField(max_length=1000, default=None, blank=True, null=True)
    F1Mean = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    accuracyBest = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    CMBest = models.CharField(max_length=100000, default=None, blank=True, null=True)
    CMNormBest = models.CharField(max_length=100000, default=None, blank=True, null=True)
    F1ByLabel = models.CharField(max_length=20000, default=None, blank=True, null=True)
    FPRByLabel = models.CharField(max_length=20000, default=None, blank=True, null=True)
    TNRByLabel = models.CharField(max_length=20000, default=None, blank=True, null=True)
    precisionByLabel = models.CharField(max_length=20000, default=None, blank=True, null=True)
    recallByLabel = models.CharField(max_length=20000, default=None, blank=True, null=True)
    F1Weighted = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    FPRWeighted = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    TNRWeighted = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    precisionWeighted = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    recallWeighted = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    
class MulticlassRandomForestResult(models.Model):
    
    # Automatic Id    
    Id = models.AutoField(primary_key=True)
    
    # Automatic Datetime - It will be set to the time the instance is first created
    dateOfCreation = models.DateTimeField(default=now, editable=False)
    
    # name of the model
    model = models.CharField(max_length=1000, default=None, blank=True, null=True)
    
    # Execution time
    executionTime = models.CharField(max_length=1000, default=None, blank=True, null=True)
    
    # Algorithm Parameters
    maxDepth = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    maxBins = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    minInstancesPerNode = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    minInfoGain = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    maxMemoryInMB = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    impurity = models.CharField(max_length=200, default=None, blank=True, null=True)
    subsamplingRate = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    featureSubsetStrategy = models.CharField(max_length=200, default=None, blank=True, null=True)
    numTrees = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    bootstrap = models.BooleanField(default=None, blank=True, null=True)
    
    parallelism = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    numFolds = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    
    # Dataframe Schema
    dfSchema = models.CharField(max_length=20000, default=None, blank=True, null=True)
    dfShow = models.CharField(max_length=40000, default=None, blank=True, null=True)
    dfShape = models.CharField(max_length=200, default=None, blank=True, null=True)
    
    # Algorithm Results
    labelMapping = models.CharField(max_length=1000, default=None, blank=True, null=True)
    F1Mean = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    accuracyBest = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    CMBest = models.CharField(max_length=100000, default=None, blank=True, null=True)
    CMNormBest = models.CharField(max_length=100000, default=None, blank=True, null=True)
    F1ByLabel = models.CharField(max_length=20000, default=None, blank=True, null=True)
    FPRByLabel = models.CharField(max_length=20000, default=None, blank=True, null=True)
    TNRByLabel = models.CharField(max_length=20000, default=None, blank=True, null=True)
    precisionByLabel = models.CharField(max_length=20000, default=None, blank=True, null=True)
    recallByLabel = models.CharField(max_length=20000, default=None, blank=True, null=True)
    F1Weighted = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    FPRWeighted = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    TNRWeighted = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    precisionWeighted = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    recallWeighted = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)

class MulticlassNaiveBayesResult(models.Model):
    
    # Automatic Id    
    Id = models.AutoField(primary_key=True)
    
    # Automatic Datetime - It will be set to the time the instance is first created
    dateOfCreation = models.DateTimeField(default=now, editable=False)
    
    # name of the model
    model = models.CharField(max_length=1000, default=None, blank=True, null=True)
    
    # Execution time
    executionTime = models.CharField(max_length=1000, default=None, blank=True, null=True)
    
    # Algorithm Parameters
    smoothing = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    modelType = models.CharField(max_length=200, default=None, blank=True, null=True)
    
    parallelism = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    numFolds = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    
    # Dataframe Schema
    dfSchema = models.CharField(max_length=20000, default=None, blank=True, null=True)
    dfShow = models.CharField(max_length=40000, default=None, blank=True, null=True)
    dfShape = models.CharField(max_length=200, default=None, blank=True, null=True)
    
    # Algorithm Results
    labelMapping = models.CharField(max_length=1000, default=None, blank=True, null=True)
    F1Mean = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    accuracyBest = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    CMBest = models.CharField(max_length=100000, default=None, blank=True, null=True)
    CMNormBest = models.CharField(max_length=100000, default=None, blank=True, null=True)
    F1ByLabel = models.CharField(max_length=20000, default=None, blank=True, null=True)
    FPRByLabel = models.CharField(max_length=20000, default=None, blank=True, null=True)
    TNRByLabel = models.CharField(max_length=20000, default=None, blank=True, null=True)
    precisionByLabel = models.CharField(max_length=20000, default=None, blank=True, null=True)
    recallByLabel = models.CharField(max_length=20000, default=None, blank=True, null=True)
    F1Weighted = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    FPRWeighted = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    TNRWeighted = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    precisionWeighted = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    recallWeighted = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    
class DecisionTreeRegressionResult(models.Model):
    
    # Automatic Id    
    Id = models.AutoField(primary_key=True)
    
    # Automatic Datetime - It will be set to the time the instance is first created
    dateOfCreation = models.DateTimeField(default=now, editable=False)
    
    # name of the model
    model = models.CharField(max_length=1000, default=None, blank=True, null=True)
    
    # Execution time
    executionTime = models.CharField(max_length=1000, default=None, blank=True, null=True)
    
    # Algorithm Parameters
    maxDepth = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    maxBins = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    minInstancesPerNode = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    minInfoGain = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    maxMemoryInMB = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    impurity = models.CharField(max_length=200, default=None, blank=True, null=True)
    
    parallelism = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    numFolds = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    
    # Dataframe Schema
    dfSchema = models.CharField(max_length=20000, default=None, blank=True, null=True)
    dfShow = models.CharField(max_length=40000, default=None, blank=True, null=True)
    dfShape = models.CharField(max_length=200, default=None, blank=True, null=True)
    
    # Algorithm Results
    RMSEMean = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    MAEBest = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    MAPEBest = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    MSEBest = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    RMSEBest = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    R2Best = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    RegressionPlot = models.CharField(max_length=100000, default=None, blank=True, null=True)
    
class RandomForestRegressionResult(models.Model):
    
    # Automatic Id    
    Id = models.AutoField(primary_key=True)
    
    # Automatic Datetime - It will be set to the time the instance is first created
    dateOfCreation = models.DateTimeField(default=now, editable=False)
    
    # name of the model
    model = models.CharField(max_length=1000, default=None, blank=True, null=True)
    
    # Execution time
    executionTime = models.CharField(max_length=1000, default=None, blank=True, null=True)
    
    # Algorithm Parameters
    maxDepth = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    maxBins = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    minInstancesPerNode = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    minInfoGain = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    maxMemoryInMB = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    impurity = models.CharField(max_length=200, default=None, blank=True, null=True)
    subsamplingRate = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    numTrees = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    featureSubsetStrategy = models.CharField(max_length=200, default=None, blank=True, null=True)
    bootstrap = models.BooleanField(default=None, blank=True, null=True)
    
    parallelism = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    numFolds = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    
    # Dataframe Schema
    dfSchema = models.CharField(max_length=20000, default=None, blank=True, null=True)
    dfShow = models.CharField(max_length=40000, default=None, blank=True, null=True)
    dfShape = models.CharField(max_length=200, default=None, blank=True, null=True)
    
    # Algorithm Results
    RMSEMean = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    MAEBest = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    MAPEBest = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    MSEBest = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    RMSEBest = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    R2Best = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True) 
    RegressionPlot = models.CharField(max_length=100000, default=None, blank=True, null=True)
    
class GBTRegressionResult(models.Model):
    
    # Automatic Id    
    Id = models.AutoField(primary_key=True)
    
    # Automatic Datetime - It will be set to the time the instance is first created
    dateOfCreation = models.DateTimeField(default=now, editable=False)
    
    # name of the model
    model = models.CharField(max_length=1000, default=None, blank=True, null=True)
    
    # Execution time
    executionTime = models.CharField(max_length=1000, default=None, blank=True, null=True)
    
    # Algorithm Parameters
    maxDepth = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    maxBins = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    minInstancesPerNode = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    minInfoGain = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    maxMemoryInMB = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    impurity = models.CharField(max_length=200, default=None, blank=True, null=True)
    subsamplingRate = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    featureSubsetStrategy = models.CharField(max_length=200, default=None, blank=True, null=True)
    maxIter = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    lossType = models.CharField(max_length=200, default=None, blank=True, null=True)
    validationTol = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    stepSize = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    minWeightFractionPerNode = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    
    parallelism = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    numFolds = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    
    # Dataframe Schema
    dfSchema = models.CharField(max_length=20000, default=None, blank=True, null=True)
    dfShow = models.CharField(max_length=40000, default=None, blank=True, null=True)
    dfShape = models.CharField(max_length=200, default=None, blank=True, null=True)
    
    # Algorithm Results
    RMSEMean = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    MAEBest = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    MAPEBest = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    MSEBest = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    RMSEBest = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    R2Best = models.DecimalField(max_digits=20, decimal_places=5, default=None, blank=True, null=True)
    RegressionPlot = models.CharField(max_length=100000, default=None, blank=True, null=True)